# Roblox +1 Simulator — Agent Blueprint Pack

**What this is:** A detailed implementation instruction pack for an autonomous Roblox Luau / Roblox Studio AI agent. It is **not an already-coded Roblox game**.

## Where to begin

1. Read `PROJECT_STRUCTURE.md` for a high-level overview of the project.
2. Read `PLUS_ONE_GAME_TEMPLATE_AGENT_SPEC.md` (full master spec, >20,000 words).
3. Inspect all screenshots in `references/` (16 user-supplied images renamed by feature).
4. Review `example_config/*.luau` for ready-to-adapt data catalogs (examples only).
5. Paste `AGENT_START_PROMPT.txt` into the coding agent or use its instructions as a system/task prompt.
6. Ask the agent to build an actual playable Roblox Studio file and verify the tests.

## Scope

- Skill → XP/Level → Throw → Wins → Stone upgrades → Training pools → Rebirth → Worlds
- Desktop, mobile and gamepad UI; shop; daily/playtime rewards; welcome chest
- Pets, boosts, trails, safe Robux purchases, global boards, settings
- Security, persistence, multiplayer and negative/exploit testing

## Critical caveats

- Reference screenshots belong to the user and are included for visual analysis only. Do not extract icon art from them or imitate a particular game's proprietary models.
- Real Game Pass IDs, Developer Product IDs, Group ID, publishing credentials, and uploaded art are **not** present. The spec requires these to remain disabled/unconfigured until owner supplies them.
- Actual Roblox Studio playtesting and publishing must be done by an agent or developer with the appropriate tooling/access.
- `example_config/` is **not** a complete Rojo game or runtime; it is a convenience set of catalog examples.

## Traceability

`references/01...16...` map to feature areas in Section 1 and Appendix B of the master spec. Check `TEST_RESULTS.md` and the Definition of Done before accepting a generated game as finished.
