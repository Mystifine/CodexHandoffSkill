# Screenshot Reference Index

These are the 16 user-provided reference images, renamed by feature for the building agent. They are **reference-only**, not reusable UI icon assets.

- [01_skill_stone_pedestals_perspective.png](references/01_skill_stone_pedestals_perspective.png)
- [02_rebirth_pools_wide_view.png](references/02_rebirth_pools_wide_view.png)
- [03_bottom_left_currency_hud.png](references/03_bottom_left_currency_hud.png)
- [04_full_lobby_and_core_hud.png](references/04_full_lobby_and_core_hud.png)
- [05_throw_zone_waterway.png](references/05_throw_zone_waterway.png)
- [06_skill_stone_costs_and_tiers.png](references/06_skill_stone_costs_and_tiers.png)
- [07_group_claim_chest.png](references/07_group_claim_chest.png)
- [08_free_reward_modal.png](references/08_free_reward_modal.png)
- [09_global_leaderboard_wall.png](references/09_global_leaderboard_wall.png)
- [10_rebirth_modal.png](references/10_rebirth_modal.png)
- [11_world_two_portal.png](references/11_world_two_portal.png)
- [12_starter_pack_shop.png](references/12_starter_pack_shop.png)
- [13_shop_afk_automations.png](references/13_shop_afk_automations.png)
- [14_daily_rewards.png](references/14_daily_rewards.png)
- [15_settings_panel.png](references/15_settings_panel.png)
- [16_update_log.png](references/16_update_log.png)

See Section 1 and Appendix B of the master specification for intended mechanics and visual lessons.
