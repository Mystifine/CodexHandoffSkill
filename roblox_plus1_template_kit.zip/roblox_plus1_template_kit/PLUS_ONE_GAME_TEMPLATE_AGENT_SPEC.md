# MASTER BUILD SPECIFICATION — MODULAR ROBLOX “+1” SIMULATOR TEMPLATE

**Document ID:** PLUS1-TEMPLATE-001  
**Version:** 1.0 (reference-capture baseline, October 2026)  
**Audience:** Autonomous/agentic coding and game-building AI with access to Roblox Studio and/or a Roblox project filesystem.  
**Output goal:** A real, editable, fully playable Roblox Studio experience, **not** a UI-only prototype, set of design mockups, or a description of what could be built.  
**Primary implementation language:** Luau (Roblox).  
**Supported workflow:** Prefer Rojo-compatible files plus a `.rbxlx` or `.rbxl` place; if Rojo is unavailable, assemble equivalent Instances and ModuleScripts in Studio.  
**Game working title:** `+1 Launch Skill Simulator` (all title, stat names, world themes, and icons configurable).  
**Reference screenshots:** Sixteen images under `references/`. The names, icons, and layouts are visual inspiration, **not assets to extract or copy**.

---

## 0. DIRECTIVE TO THE IMPLEMENTING AI — READ BEFORE WRITING ANY CODE

You are the implementation agent. Build a **feature-complete, configuration-driven +1 Roblox game starter template** following this document. The reference gameplay is a bright, toy-like Roblox simulator in which players gain **Skill**, earn **Wins** by performing a physical action in a throw zone, spend Wins on **Skill stones** that raise the flat Skill gain, train in zones giving multiplicative Skill gain, level up, rebirth for permanent multipliers, acquire Pets/Trails/Boosts, claim daily/playtime rewards, unlock Worlds, and optionally purchase Robux products.

**Rules that override implementation shortcuts:**

1. **Produce runnable artifacts.** All buttons and pads must be interactive, core data must persist, purchases must be implemented securely, level calculations must be functional, and the environment must be navigable. An attractive static screen without real game logic fails.
2. **Reusable template, not a bespoke clone.** Place economy, world, branding, purchase products, pad counts, decorative themes, UI copy, rewards, and formulas in configuration tables. Avoid hardcoding those values inside UI components or service logic.
3. **No assumed access.** If you cannot actually open Roblox Studio, connect to a live Roblox universe, publish assets, configure passes, or publish a place, state that limitation in the final handoff; still provide complete source and build scripts. Never claim a live test or a published product occurred unless it actually did.
4. **No fake IDs.** Any `GamePassId`, `ProductId`, `GroupId`, `PlaceId`, icon/asset ID, or soundtrack ID that is not supplied remains `0`/`nil` with a visible developer warning and the relevant purchase action disabled. Never display false Robux prices; source live prices where available.
5. **Authoritative server.** The client may render predicted animations, but the server owns Skill, Wins, levels, rebirths, permissions, inventory, rewards, purchases, and saved data.
6. **Purchase integrity.** Developer Products are awarded from a server receipt handler with idempotent handling, not from purchase-prompt completion. A receipt must never be acknowledged if its reward has not been durably granted.
7. **Persistence integrity.** Never silently replace a player's progress with starter values because a datastore read failed. Prevent double-awarding, multiple-server overwrites, and partial purchase grants.
8. **Preserve usability.** Keyboard/mouse, touch, controller, safe area, small devices, differing aspect ratios, and color-vision accessibility matter. No controls may be hidden behind Roblox CoreGui or notches.
9. **Prioritize core loop before extras.** Finish Skill → Level → Throw → Wins → Stones → Training Pools → Rebirth → Save/Load before pets, storefront, decorative polish, or analytics.
10. **No manipulative dark patterns.** Monetization must be clearly labeled; show factual rewards/prices and provide free-play paths. Do not make unverifiable claims that users have liked/favorited a game. Avoid copying exact logos, art, text, or trademarks from the screenshots.
11. **Agent execution:** Maintain `IMPLEMENTATION_STATUS.md`, `ASSUMPTIONS.md`, `KNOWN_ISSUES.md`, and `TEST_RESULTS.md`; mark tasks `NOT STARTED`, `IN PROGRESS`, `DONE`, or `BLOCKED`; validate each subsystem before proceeding; stop only after meeting the Definition of Done or explicitly documenting blockers.
12. **When uncertainty arises:** choose the configurable default specified here, log the assumption, and continue. Ask the owner only for genuinely blocking identifiers/permissions, not routine stylistic choices.

### Required final outputs from the implementation agent

- Openable Roblox Studio place (`.rbxl`/`.rbxlx`) **or** complete Rojo project with documented export-to-Studio steps; ideally both.
- All Luau source files, model hierarchy, UI hierarchy, central config, and test scripts.
- Demonstration play session proving Skill gain, Level progress, Wins payouts, purchases with test configuration, rebirth, world gating, rewards, and persistence across rejoins.
- `README.md` with setup, installation, publishing checklist, gamepass/product configuration, datastore setup, and how to create a new theme.
- `TEST_RESULTS.md` with pass/fail status and evidence for core tests, not a list of planned tests.
- `KNOWN_ISSUES.md` with exact limitations and repro steps; no quiet omissions.

### Feature priorities

- **P0:** Spawn/lobby, stone upgrade stations, at least four training pools, throw mechanic, HUD, level bar, rebirth, server validation, save/load, world portal, usable shop skeleton, daily rewards, basic settings.
- **P1:** All seven training lanes, all ten stones, shop purchase flows, packs, leaderboard boards, pets, trails, playtime gifts, reward chest, UI polish, responsive design.
- **P2:** Multiple themed worlds with unique presentation, developer analytics, special seasonal events, rotating relics, multiple egg pools, update log admin tooling, extensive VFX.

---

## 1. SCREENSHOT STUDY AND REFERENCE MANIFEST

The ZIP includes all sixteen source screenshots relabeled for easy agent navigation. The image files are **reference-only**. Agent should examine them at native resolution before modeling and revisit the corresponding reference while implementing each feature.

| Reference | What to look at | Mandatory behaviors / visual lessons |
|---|---|---|
| `references/01_skill_stone_pedestals_perspective.png` | Tiered stepped dais, shell/starfish/stone icons, outlined text `LOCKED`, `UNLOCKED`, +Skill quantities, yellow Wins prices | Stone prices are a **flat base gain** upgrade using Wins; floating text legible at distance; 3D prompt interaction |
| `references/02_rebirth_pools_wide_view.png` | Parallel colored pads/pools: 1x, 4x, 10x, 20x for 0/2/4/6 rebirth, 3x/15x/50x premium pads | Separate multiplier-zone purchases from base stones; locked physical access indicated clearly |
| `references/03_bottom_left_currency_hud.png` | Compact rebirth arrows count, trophy Wins count, Friend Boost text with green plus | Always-visible bottom-left counters and a friend-bonus explanation/action |
| `references/04_full_lobby_and_core_hud.png` | Combined shop/nav, progression HUD, resource popups, throw water, pool panels, quick-buy cards | Highest-priority screenshot for initial HUD composition and lobby density |
| `references/05_throw_zone_waterway.png` | Long lane, yellow `THROW ZONE`, large blue water surface, travel depth, World/biome decoration | Central active action to convert Skill into Wins; visible spectacle and distance feedback |
| `references/06_skill_stone_costs_and_tiers.png` | Full cost/gain lineup; lime/unlocked and red/locked, light lavender stud floor | Use all ten default stone tiers; avoid clutter and occlusion |
| `references/07_group_claim_chest.png` | Glowing chest, circular ground aura, `CLAIM`, group messaging | Physical one-time bonus reward point; transparent eligibility state |
| `references/08_free_reward_modal.png` | Large gift header, text, reward `+10,000 Skill`, bright verify button | Optional group/community panel; don't falsely verify likes/favorites |
| `references/09_global_leaderboard_wall.png` | Four large leaderboard boards with titles, ranks, avatars, neon beams | Boards for Top Level, Playtime, Robux Spent, Wins (add Rebirths as needed) |
| `references/10_rebirth_modal.png` | Before/After multiplier, reset warning, Level X/Y requirement, green Rebirth, paid skip | Rebirth increases permanent power; clear reset disclosure; progress bar |
| `references/11_world_two_portal.png` | Framed aqua swirl with sign `WORLD 2`, `THROW WITH 100M` | Configurable world unlock gate; movement/teleport feedback |
| `references/12_starter_pack_shop.png` | Shop, Starter Pack, Demon Pack, contents icons and sale-like styling | Data-driven bundle contents; display actual configured price; no invented discount |
| `references/13_shop_afk_automations.png` | Shop rows for `AFK WINS` and `AFK REBIRTHS`, gift shortcuts | Gamepass automation features; buy vs owned states, explicit impact |
| `references/14_daily_rewards.png` | Seven-day grid with pet, boosts, limited trail/relic; timer | Account-scoped 7-day calendar with claimable/claimed/locked states |
| `references/15_settings_panel.png` | Sound, Music, Camera Shake, Effects, Hide HUD | Working sound/visual toggles and sliders; mobile-friendly touch targets |
| `references/16_update_log.png` | Dated multi-update list for worlds, stones, eggs, pets, ponds | Configurable patch-note screen; never imply unbuilt features shipped |

### Screenshot-specific observations, not guaranteed facts

- Example Stone ladder visible: `+1 Skill / 0 Wins`, `+3 / 2`, `+5 / 10`, `+12 / 40`, `+30 / 150`, `+75 / 500`, `+200 / 1.5K`, `+500 / 4.5K`, `+1.25K / 14K`, `+3.5K / 40K`.
- Basic training lanes appear to be `1x (0 rebirths)`, `4x (2)`, `10x (4)`, `20x (6)`; premium lanes show `3x`, `15x`, `50x` with Robux icons/prices.
- Rebirth modal shows `x4 Skill → x5 Skill` and `Level 72 / Level 80` in the same visual example; a reasonable configurable default is **base multiplier 1 + rebirth count** and **level cap 50 + 10 × rebirth count**.
- One screenshot shows `Level 58` with a `72%` rebirth meter, which matches 58/80 (rounded) at three rebirths. This is a useful consistency target for the default HUD model.
- Another screenshot depicts some later stones as `UNLOCKED` even while earlier ones read `LOCKED`; **do not invent hidden prerequisites**. Handle stone ownership/equipment explicitly and never conflate affordability with ownership.
- Skill and Wins counters, boosts, multipliers, and rewards change dynamically; screenshot numbers are illustrative, not hard-coded target player values.
- The screenshots show both progression and monetization systems; do not infer that every product named is a standard Game Pass. This spec defines intentional product types below.

---

## 2. GAME IDENTITY AND DEFAULT LOOP

**Theme:** Colorful toy-brick fantasy/simulator. Simple shapes, chunky outlines, readable signs, warm sky, lime square-stud grass, lavender/off-white stud paths, bright colored pools, orange checkerboard cliffs, tall low-poly trees, eggs/chests, floating currency. **Do not reuse any existing game's proprietary models/art/audio.** Create original stylized art or use legally permitted placeholders until originals are available.

**Player loop in 12 seconds:** Spawn → stand on a colorful training lane → earn Skill per second → gain Levels → enter the long THROW ZONE → throw/launch yourself or a projectile → earn Wins based on Skill and distance → visit Stone Shop → spend Wins to increase your **flat Skill per second** → stand in better training lanes for higher multipliers → hit your current level cap → Rebirth → permanent Skill multiplier increases → repeat with new worlds, eggs, trails, and rewards.

**Three nested retention loops:**

1. **Seconds (3–15 s):** Skill number ticks, floating `+Skill`, level bar moves, occasional level-up sparkle, progress towards next stone or launch.
2. **Minutes (2–15 min):** Wins purchase better base stone, better pool unlock, new Throw milestones, pet eggs, first rebirth.
3. **Days:** Daily rewards, playtime claimables, leaderboard targets, quests/world expansions, collectible pets/trails, update announcements.

**Template personalization contract:** A new project must be re-themeable by editing `ThemeConfig`, `EconomyConfig`, `WorldConfig`, `ShopCatalog`, `RewardConfig`, and swapping icon/model assets. No other source file changes should be needed for a different stat name (e.g., Strength, Health, Mana, Speed), action (e.g., Throw, Race, Jump), or visual biome if the relevant adapter is supplied.

**MVP for a single new player:** Starting Skill 0, Wins 0, Rebirths 0, equipped `StarterStone` +1 flat Skill/tick, initial Level 1, basic 1x pool accessible, first throw pad available from start, all advanced stations visible with lock descriptions. The player must be able to earn the first 2 Wins, purchase `+3 Skill`, improve their pace, reach the first Level cap, rebirth, and persist all progress without spending Robux.

### Vocabulary / no ambiguity

- **Skill (`skill`)**: Current-life power displayed in HUD and used for world gates, throw distance, and leaderboard if desired. **Reset to 0 on rebirth.**
- **Level XP (`levelXp`)**: Within-level progression, awarded alongside Skill and applied to level thresholds. **Reset to 0 on rebirth.**
- **Level (`level`)**: Current-life integer level; starts at 1, advances when XP thresholds are met, capped by Rebirth state.
- **Wins (`wins`)**: **Spendable, persistent** soft currency awarded from throwing; purchases Stone upgrades and eggs. **Do not reset on rebirth.**
- **Lifetime Wins (`lifetimeWins`)**: Sum of Wins earned, unaffected by purchases; drives permanent win leaderboards.
- **Rebirths (`rebirths`)**: Permanent integer; grows the base Skill multiplier and raises max Level. Rebirths are not currency unless configured explicitly.
- **Stone (`stoneId`)**: Owned flat Skill/tick base upgrade; the equipped stone decides the base Skill gain before multipliers; owned upgrades persist through rebirth.
- **Training Pool (`zoneId`)**: Multiplicative station; the player's *current* zone multiplier applies to training while inside. Pool access is gated by rebirth count and/or verified ownership of pass.
- **Skill multiplier (`Mskill`)**: Computed on server from rebirths, pool, passes, boosts, friend bonus, pet effects, and event modifiers.
- **Win multiplier (`Mwin`)**: Separately computed on server; affects thrown Wins but not Skill.
- **World**: Playable themed area with its own stations, throw lane, eggs, and/or decorative models. Access via a configured Skill threshold, not by hidden premium locks.
- **Premium currency**: Robux; handled by Roblox marketplace only, never represented as custom player-owned in-game balances.

---

## 3. MINIMUM DEMONSTRABLE CONTENT

Build a launchable **World 1: Pumpkin Harbor / Toy Island** with: lobby; spawn; ten purchaseable Stone stations; four rebirth-gated pools and three premium pools; long water throw zone; portal to **World 2: Palm Beach**; local leaderboard wall; four global boards; gift chest; pet egg stand; shop; daily-reward UI; settings; update log; rebirth modal; skill/Win HUD; readable signs; accessible paths. Create World 2 with at least a distinct island, palm-tree appearance, training+throw station config, portal back, and appropriate World gating. World 3+ may be data-defined and clearly marked as unbuilt; do not show fake available worlds.

**Default player settings:** WalkSpeed 16, JumpPower/default platform-safe, simple R15 avatar compatible; teleport to safe spawn after every rebirth. Fall/death plane below map returns player safely without wiping inventory. Player spawn protection 3 seconds; no PvP required.

**Maximum server size:** 16 as initial target. All critical systems must operate with at least 8 simultaneous players and tolerate 16 without overburdening server or UI. Avoid a global Heartbeat loop per clickable object.

**Supported devices:** PC mouse/keyboard, mobile portrait/landscape, tablet, console/gamepad. Minimum acceptable play size: small portrait handset with scrolling menus and a compact overlay; do not optimize only for 1920×1080 screenshot.

**Target feel:** Input response <150ms where latency permits (animation predicts, currency confirmed by server); gain ticks feel every 1 second; Level-up animation ~0.8 s; Stone purchase acknowledgement ~0.25 s; portal hold/confirmation ~0.4 s; throw experience 2–4 s before payoff; HUD animations never block gameplay.

---

## 4. CONFIGURATION FIRST — CANONICAL TABLES

Use single-source-of-truth ModuleScripts in `ReplicatedStorage/Shared/Config` for **public, non-sensitive static data**, and server-only settings in `ServerScriptService/Server/Config` for anti-cheat, store keys, and operations. Price displays and cost calculations must both reference the same config entry. Clients can see base prices, descriptions, and icons, but cannot decide whether a purchase should succeed.

### 4.1 Starter Stone ladder (exact reference-inspired defaults)

| `id` | Display | Flat Skill / training tick | Cost (Wins) | Unlock behavior | Visual |
|---|---|---:|---:|---|---|
| `starter` | `+1 Skill` | 1 | 0 | Default owned | Gray pebble |
| `shell` | `+3 Skill` | 3 | 2 | Purchasable | Pearlescent shell |
| `spiral` | `+5 Skill` | 5 | 10 | Purchasable | Orange spiral shell |
| `starfish` | `+12 Skill` | 12 | 40 | Purchasable | Orange starfish |
| `wood` | `+30 Skill` | 30 | 150 | Purchasable | Wood cross-section |
| `sail` | `+75 Skill` | 75 | 500 | Purchasable | Red triangular gem |
| `ring` | `+200 Skill` | 200 | 1,500 | Purchasable | Blue-rimmed ring |
| `gold` | `+500 Skill` | 500 | 4,500 | Purchasable | Gold medallion |
| `dark` | `+1.25K Skill` | 1250 | 14,000 | Purchasable | Dark obsidian disk |
| `coral` | `+3.5K Skill` | 3500 | 40,000 | Purchasable | Red coral circle |

**Ownership:** A purchased Stone stays owned across rebirths/rejoins. Buying a Stone grants ownership and auto-equips it **if** it is better than the equipped Stone. Lower Stone stations show `OWNED` or `EQUIP`; unowned show `LOCKED` with purchase price if unaffordable and `BUY` if affordable. The text `LOCKED` describes access—not exclusive ownership. Allow buying any tier if Wins suffice; do not require owning every preceding tier, unless a separate config flag `RequirePreviousStone = true` is enabled (default **false**, reflecting the screenshot's mixed unlocked states). Duplicate purchases must never charge twice.

### 4.2 Training pools

| Zone | Color | Multiplier | Unlock requirement | Intended access |
|---|---|---:|---|---|
| `training_basic` | Aqua | 1x | 0 Rebirths | Free |
| `training_green` | Turquoise | 4x | 2 Rebirths | Earned |
| `training_violet` | Purple | 10x | 4 Rebirths | Earned |
| `training_azure` | Pale blue | 20x | 6 Rebirths | Earned |
| `training_blue_premium` | Navy | 3x | `pool3x` Game Pass | Optional paid |
| `training_gold_premium` | Gold | 15x | `pool15x` Game Pass | Optional paid |
| `training_neon_premium` | Black/green neon | 50x | `pool50x` Game Pass | Optional paid |

**No stacking pools:** Player may occupy exactly **one active training zone** at a time; the selected/last confirmed server-side valid zone applies. If overlapping triggers are touched, resolve via high confidence geometry and server-side center-point, with deterministic priority and a 0.2s boundary debounce. When not in any pool, use `LobbyTrainingMultiplier = 1` **but gain requires active training** by default (`PassiveLobbyTraining = false`). Pool premium ownership never expires if represented as Game Pass.

**Ownership precedence:** If a player owns a premium 3x pass but has 10x free pool access, the 3x pass does **not** automatically stack with 10x or increase 10x. It unlocks a specific pool; player intentionally occupies desired one. All multipliers displayed reflect the currently selected pool.

### 4.3 Default economy parameters

| Key | Default | Meaning |
|---|---:|---|
| `TrainingTickSeconds` | 1.0 | Server grants once per eligible training tick |
| `BaseRebirthMultiplier` | 1.0 | Skill multiplier at 0 rebirths |
| `RebirthMultiplierPerRebirth` | 1.0 | `1 + rebirths` gives x4 when 3 rebirths |
| `FirstLevelCap` | 50 | First rebirth at Level 50 |
| `LevelCapPerRebirth` | 10 | Level cap grows to 80 at 3 rebirths |
| `XPPerSkillAwardScale` | 1.0 | Default Level XP gain proportional to final awarded Skill; tuning allowed |
| `ThrowCooldownSeconds` | 3.0 | Prevent double-payment from throw spam |
| `BaseThrowRangeStuds` | 28 | Visible nonzero launch for novices |
| `ThrowDistanceLogCoefficient` | 48 | Scale with log10(Skill) |
| `ThrowDistanceSkillDivisor` | 20 | Makes low-level throws meaningful |
| `ThrowLaneLengthStuds` | 600 | Rendered throw distance cap |
| `WinsPerDistanceStuds` | 12 | One base Win per ~12 studs, minimum 1 |
| `FriendBonusPerFriend` | 0.10 | +10% Skill with one server friend |
| `MaxFriendBoost` | 0.50 | Cap bonus at +50%; 5 friends |
| `AutoTrainEnabledByDefault` | true | Standing on pool automatically trains |
| `AutosaveSeconds` | 90 | Randomize jitter ±10 sec; budget aware |
| `BoardRefreshSeconds` | 120 | Global boards, with throttled cache |
| `World2RequiredSkill` | 100000000 | `100M Skill`; configurable |
| `DailyCooldownSeconds` | 86400 | 24h from previous claim (MVP) |
| `MaxStatSafeValue` | 9e15 | Protect integers from unsafe float precision; clamp/log |

**Progression knobs are hypothetical balancing defaults**, not faithful reverse-engineering of the example game's actual formula. Document tuning outcomes using automated simulations, then refine constants without rewriting services.

---
## 5. EXACT MATH, TRANSACTION ORDER, AND PROGRESSION RULES

**Never mix visual formatting with underlying numeric storage.** Internally use finite nonnegative numbers bounded by `MaxStatSafeValue`; all rates are precomputed server-side. Use precision-safe integer increments whenever possible; reject NaN, infinity, decimals for count-only inputs, and overflow.

### 5.1 Server Skill per tick

```
BaseSkill = StoneCatalog[profile.equippedStoneId].baseSkill
PoolMult = ActiveTrainingZone.multiplier   -- e.g. 1, 4, 10, 20, 3, 15, 50
RebirthMult = 1 + profile.rebirths * RebirthMultiplierPerRebirth
PassMult = 2 if verified doubleSkill pass OR permanent bundleSkill2x entitlement else 1
PetMult = 1 + SUM(equippedPets[i].skillBonusFraction), capped at configured maximum
FriendMult = 1 + MIN(friendCountInCurrentServer * 0.10, 0.50)
BoostMult = 2 if temporary double-skill boost currently active else 1
RelicMult = configured equipped relic multiplier or 1
EventMult = configured active event multiplier or 1
WorldSkillMult = current world training multiplier or 1

RawSkill = BaseSkill * PoolMult * RebirthMult * PassMult *
           PetMult * FriendMult * BoostMult * RelicMult *
           EventMult * WorldSkillMult
FinalSkillAward = clamp(floor(RawSkill + 0.5), 1, MaxAwardPerTick)
XPGrant = clamp(floor(FinalSkillAward * XPPerSkillAwardScale + 0.5), 1, MaxAwardPerTick)
```

Rules: never award outside a valid pad if `PassiveLobbyTraining=false`. Never award to unloaded/kicked players or when the profile is read-only. Training tick scheduling uses accumulated elapsed time capped at one grant per one-second interval; do not award thousands of seconds of fake catch-up from a server hiccup. Each server tick measures authoritative zone occupancy; the client never sends a claimed multiplier or Skill amount. If Roblox physics/Region3 detection is temporarily ambiguous, keep previously valid zone for at most 0.5s, then revert to none. Paused/null characters cannot train.

**Example, not promise of screenshot accuracy:** A player with +3 stone, x4 pool, 2 rebirths, 2x pass, no pets/boosts/friends gains `3 * 4 * 3 * 2 = 72 Skill/second`. A player with +5 stone, x10 pool, 3 rebirths, 1.2 pet multiplier gains `5 * 10 * 4 * 1.2 = 240 Skill/sec`. Display gain popup `+240` at pad and Skill change in HUD, never `+285` unless actually awarded 285.

### 5.2 XP/Level derivation

Level is NOT simply `floor(Skill/1000)`. Maintain current `level`, `levelXp`, and cap. XP requirements use a configurable curve, default:

```
XPToNextLevel(level) = roundToNearest10(100 + 2.087 * level^2)
LevelCap(rebirths)   = FirstLevelCap + LevelCapPerRebirth * rebirths
```

This gives approximately 7.12K XP required for Level 58 -> 59, matching the scale of the pictured bar, without claiming the original game uses this curve. Implement `roundToNearest10(x) = floor(x/10 + 0.5)*10`.

**XP update algorithm (server):**

1. Add `XPGrant` to `levelXp`, if at cap hold `levelXp=0` and do not silently let levels exceed the cap.
2. While `level < LevelCap(rebirths)` and `levelXp >= XPToNextLevel(level)`, subtract the threshold and increment `level`.
3. Cap at current max; if at cap, set `levelXp=0`, `canRebirth=true`.
4. Broadcast one compact state delta and optional `LevelsGained` event (if multiple levels skipped, show one `+N Levels` toast, not 100 toasts).
5. Recompute percentage `clamp(level / LevelCap(rebirths),0,1)` for left `Rebirth` button. For precise progress toward next rebirth, document if fraction of current level XP is included; default badge **uses level/cap** to match screenshots.

**Large Skill award:** Level calculation uses a loop with upper iteration limit or a precomputed cumulative XP threshold/binary search. If a 1M Developer Product is purchased, do not cause 10,000 frame stalls. The implementation must handle 1e12 safely without dividing by zero.

### 5.3 Throw distance and Wins

The reference uses a physical **THROW ZONE** along a long canal. Implement a launch interaction that is rewarding visually, secure economically, and does not require dangerous arbitrary character physics. **Recommended MVP:** Player stands on the `ThrowStartPad`, presses `E` / taps `Throw`, a themed dummy/projectile representing the player's throw shoots down the lane (client visual), a distance marker animates to server-specified distance, and the player receives Wins. Optional polish: a safe short-lived client ragdoll/launch animation with full reset and a safe respawn. Do **not** derive rewards from a client-reported hit location, projectile part, or client-time travel.

Default server formula:

```
SkillSnapshot = max(0, profile.skill)
Distance = clamp(
    floor(28 + 48 * log10(1 + SkillSnapshot / 20)),
    28,
    World.throwLaneLength
)
BaseWins = max(1, floor(Distance / 12))
RebirthWinBonus = 1 + 0.1 * profile.rebirths  -- capped by configuration
GamePassWinMult = 2 if verified doubleWins pass OR permanent bundleWins2x entitlement else 1
PetWinMult = 1 + sum(win bonuses, bounded)
ActiveWinBoostMult = 2 if 2x Wins potion active else 1
WorldWinMult = WorldConfig[worldId].winMultiplier
FinalWins = clamp(floor(BaseWins * RebirthWinBonus * GamePassWinMult *
                         PetWinMult * ActiveWinBoostMult * WorldWinMult + 0.5),
                  1, MaxWinAwardPerThrow)
```

Use `math.log10` equivalent available in current Luau/runtime, or `math.log(x, 10)` after confirming signature. Distance is an integer stud display for predictable comparisons. Throw outcome message format: `152 STUDS!  +12 WINS` and optional animated trophy icon. The distance cap is intentionally a **visual lane cap**; worlds should have different lengths and Win multipliers, so players can advance.

**Validation sequence, in order:** valid player/session/profile → valid current world → character alive → close enough to active ThrowPad (recommended within 18 studs center, server measured) → cooldown elapsed → no active throw already pending → read current Skill from server → compute output → atomically update Wins and lifetime Wins in one in-memory profile transaction → send result to client. Mark last throw attempt server-side to stop duplicated `RemoteEvent` spam. Under platform lag, a legitimate throw may play late animation, but never pay twice.

**Thrown-object visual:** Start at `ThrowOrigin`, fly along lane cubic/eased spline in 1.8–3.0 s, small camera shake if enabled, speed trails and studs-distance counter rising, splash/ring at destination, return camera control. Particle count <=40 per throw per viewer and throttle effects beyond a practical player distance. Server should not simulate a high-speed projectile requiring every frame replication when payout is predetermined.

### 5.4 Wins spending / Stone transactions

When a Stone prompt fires, client sends only `stoneId`. Server verifies config ID, player profile loaded and writable, stone not already owned, player within configured station radius (if physical purchase, default 16 studs), allowed world and any explicit prerequisite, and `wins >= cost`. **Then** subtract cost and add ownership in a single non-yielding in-memory mutation. Equip highest Stone automatically. Return an unambiguous result code: `SUCCESS`, `ALREADY_OWNED`, `NOT_ENOUGH_WINS`, `TOO_FAR`, `INVALID_STONE`, `SAVE_UNAVAILABLE`, `WORLD_LOCKED`, `RATE_LIMITED`. Set and replicate updated Wins, stone label, equipped base gain. Save at a reasonable priority; ensure sessions are durably saved during leave and periodically, and that a crash does not create a partially serialized state.

Station state labels:

- Starter: always `UNLOCKED` and `+1 SKILL / FREE`.
- Unowned, can't afford: red `LOCKED`, white `+N SKILL`, yellow `X WINS`, prompt `Need X more Wins`.
- Unowned, can afford: lime `AVAILABLE` (not necessarily `UNLOCKED`), `+N SKILL`, yellow `COST X WINS`, prompt `Buy`.
- Owned and equipped: lime `EQUIPPED`; owned but not equipped: lime `OWNED`, prompt `Equip`.
- Disabled/config error: gray `UNAVAILABLE`, no purchase prompt.

**Edge case:** Two simultaneous `BuyStone` requests for one tier must deduct exactly once. Do not yield between affordability test and profile change. A Stone remains owned after rebirth.

### 5.5 Rebirth transaction

The Rebirth modal shows:

- Title + swirling two-arrow icon.
- `BEFORE: xN SKILL → AFTER: x(N+1) SKILL` in prominent side-by-side cards.
- Red warning: `Resets your LEVEL, SKILL and LEVEL XP. You keep WINS, STONES, PETS, TRAILS and PURCHASES.` (do **not** claim to wipe Wins; reference only says Level and Skill reset).
- Progress `Level 72 / Level 80` and horizontal bar.
- Big green `Rebirth` CTA enabled **only** at cap.
- Smaller purple `Skip Rebirth` Robux developer-product CTA if configured. Disabled with `Not configured` state otherwise.

Normal rebirth server procedure:

1. Debounced button event, validate profile loaded and writable.
2. Validate `level >= LevelCap(rebirths)`.
3. Atomically in memory: increment rebirth count by 1; reset Skill 0, Level 1, Level XP 0, active training zone none; ensure next `LevelCap` now greater; record stats/analytics idempotently.
4. Persist as soon as practical (priority save) and send resulting snapshot/delta.
5. Teleport avatar to safe world spawn; show 0.7–1.2s VFX.
6. Show new multiplier immediately on both HUD and next rebirth screen.

**Skip Rebirth product:** Must use developer product receipt award pathway; exact purchase content configured and disclosed. Default skip grants **one** rebirth even if not currently at cap, then resets Level/Skill/XP identically. Optional flags to require current cap or preserve XP MUST be explicit and default false. Repeated receipts must not increment twice. If rebirth is concurrent with a paid skip, serialize operations so there are no phantom extra rebirths.

**Starter Pack multiplier rule:** Any permanent 2x Skill or 2x Wins flag granted by a pack is equivalent in benefit to the corresponding separate 2x pass, but does not stack with that pass. Maintain this rule in Skill/Win formulas, entitlement UI, tests, and player explanations.

**Prestige scaling caution:** A player at 0 rebirth gets x1 and Level cap 50; at 3 rebirths gets x4 and cap 80; after rebirthing gets x5 and cap 90. Higher cap should balance higher gain, not become a hard wall. Use simulations to tune XP curve and stone price ladder.

### 5.6 Passive/AFK automation products

Screenshot shows `AFK WINS / Auto Win` and `AFK REBIRTHS / Auto Rebirth`. In the template these are **permanent Game Passes**:

- `autoWin`: When player is training and opted-in via a clearly labeled HUD toggle, automatically executes server-validated throw payout no more frequently than configured `AutoWinIntervalSeconds=12` **without physically launching**; user sees icon/timer and earned Wins. No AFK awards while offline. Caps apply.
- `autoRebirth`: If player opted in AND reaches Level cap, server completes normal rebirth (same reset) after a short 2s delay; no hidden immediate action. Allow disable in settings so players can keep Skill for world gates. Do not auto-rebirth when a manual confirmation modal is open and user has disabled the setting.
- Neither system can trust a client timer, and neither system consumes any Robux after initial verified Game Pass ownership.
- Clarify `AFK` means *online automation*, not offline progression. An optional offline-earn feature is a separate future system with explicit caps.

---

## 6. MAP AND WORLD BUILDER — EXACT ART-DIRECTION SPECIFICATION

Build the world with **anchored parts, terrain, meshes, Models, Attributes, and tagged interactables**. Coordinate values below are reference scale guidance, not physics invariants. Include a central `WorldOrigin` CFrame per world; child placements relative to it allow moving whole worlds without script changes.

### 6.1 Global coordinate conventions

- X increases right/east in the authored overhead plan.
- Z decreases toward “north”/throw direction; orient signage to face the spawn flow.
- Y is up; grassy ground surface around Y=0; players spawn with root above ground at Y≈6–8.
- Lobby footprint about **360 studs X × 240 studs Z**, fenced by orange block/stud cliffs. Keep large fall buffers under portals.
- Spawn approximately `(0, 7, 83)` relative to World 1 origin, facing toward negative Z.
- Ensure paths are >=12 studs wide and allow mobile camera/avatars to pass without snagging. Slope/ramp transitions should be gentle; provide ramps next to any decorative stairs where accessibility/physics needs them.

### 6.2 World 1 placement guide (start, then adjust collision/playtest)

| Object / region | Suggested relative center / span | Required details |
|---|---|---|
| `LobbyGround` | X -170..170, Z -105..110 | 8-stud-thick checker grassy pad, 4×4 or 8×8 green tile/stud texture |
| `Spawn` | (0,7,85) | Neutral platform, spawn particles small, clear sightline to lanes |
| `CentralConcourse` | X -125..120, Z 55..85 | Pale-lavender white-stud floor; path direction marked with small arrows |
| `TrainingPoolRow` | X centers -112,-80,-48,-16,16,48,80; Z 6 | Seven parallel pools each ~22×68 studs and 2–3 stud raised frame; separate 10-stud aisles |
| `TrainingPoolSouthSign` | at near end of each lane, Z 46 | `0 / 2 / 4 / 6 REBIRTHS` or `ALL WORLDS` as appropriate, clear zone ownership |
| `StoneStairDais` | East side X 125..165, Z -78..58 | 10 alternating pedestal positions in two levels, climbable broad 2–4 stud risers |
| `ThrowStartPad` | (0,1,-97) | Golden/orange strip marked `THROW ZONE`; one clear interaction location |
| `ThrowCanal` | X -85..85, Z -695..-100 | Wide blue water, bank edges with green squares, depth perspective and finish markers |
| `World2Portal` | (126,6,76) | Wood/stone ring with cyan swirl, floating World 2 gate sign |
| `GiftChest` | (-126,3,75) | Large red/gold chest, yellow circular aura; above-chest `CLAIM` header |
| `EggAndPetShop` | (124,5,40) | One large egg on pedestal, available pets icon panel and visible cost |
| `ShopSignOrKiosk` | (-128,5,37) | Floating `SHOP`/bag icon, may be UI-only clickable |
| `LeaderboardsWall` | (-105,5,95) toward perimeter | 4 or 5 angled tall green boards with wooden frames/neon lights |
| `ReturnToSpawn` | Near distant zones | Clear 'Back to Lobby' teleport button or portal |

**Important:** The reference screenshots are crowded; preserve the energetic toy-simulator feel, but improve actual legibility. Floating text must not visually overlap across ten stone stations when viewed from spawn. If necessary, move stations further apart, lower `MaxDistance`, angle BillboardGuis, or introduce 2 rows separated in Z. Do not perfectly copy the screenshot's occlusion problems.

### 6.3 Tile/floor and lighting style

- Green checker lawn: tile colors approximately `#61C93F` and `#89DB53`; occasional low-poly grass tufts and small rocks, <=1–2 props per 150 sq. studs so navigation remains clear.
- White/lavender plaza: `#DCD8FF`, `#C6C1F6` studded toy-block appearance. Use material/Texture where performant; do not instantiate millions of tiny studs.
- Orange cliffs/walls: warm checker tiles `#C87046` / `#E28B60`, 35–60 studs tall. Avoid flat giant bare walls; use modest inset squares.
- Training lanes: Aqua `#2CD8E9`, Teal `#35BFAE`, Violet `#913FF4`, LightBlue `#86B8FF`, DeepBlue `#0F388E`, Gold `#F3AE08`, NeonBlack `#071018` with fluorescent green `#30FF79` seam strips. Add rounded/squared outer frames and small corner beacons. Keep collision on decorative trim disabled.
- Sky/atmosphere: warm peaches/orange sunset, bright but low bloom; enough contrast for white/black outlined text. Lighting `Technology` selected for supported compatibility (test actual current enum), soft shadows, no heavy volumetric effects on mobile.
- Tree style: low-poly or blocky light-green cubes atop medium-brown rectangular trunks; pumpkin/jack-o-lantern props near walls; subtle seasonal theming via config. Trees cannot obstruct interactions.
- Pedestals: each 10×10 stud tile, raised platform with 1–3 tiered 0.5-stud offset rings, bright lavender. Display low-poly Stone model hovering/rotating gently by client tween, not server per-frame rotation.
- Signs: use 3D `BillboardGui` (Adornee designated invisible anchor) with text stroke dark `#121218`, `AlwaysOnTop` when required and sensible `MaxDistance` for readability. Avoid enormous BillboardGui above everything.
- Portal: ~13×18 studs, colored swirl plane/animated SurfaceGui, wood/octagonal frame, collision-free entrance, `ProximityPrompt` fallback. Sign with world name and `Requires 100M Skill` (threshold formatted from WorldConfig).

### 6.4 Throw canal staging

Canal runs away from the lobby into distant horizon. Side banks have repeated low-poly palms/pumpkins, boulders, milestones every 50–100 studs, invisible limit walls and a non-collidable water visual. Water is decorative; players do not need to swim in it. Add occasional themed arch/crossbar markers. On successful throw, animate target distance on lane HUD and (optionally) a thin beam/ribbon to landing. If camera follows the dummy, provide a Skip Camera option and a firm maximum camera lock of 3 seconds. Kill zones must never damage player profile.

### 6.5 World 2 — Palm Beach

**Gate:** Skill >= `100,000,000` at the moment of using World 2 portal, unless player has unlocked permanent access via explicitly configured system (default **no permanent access**). Because Skill resets on rebirth, the interface must say current Skill requirement plainly, and a player who rebirths in World 2 returns to World 1 unless design explicitly makes access permanent. Default world gate is temporary/current-Skill; use `worldUnlocks` only for non-Skill world requirements.

**Visual differentiation:** brighter aqua water, cream sand checkers, palm trees, turquoise sky, round rocks, tropical flowers; original color palette. World 2 has a separate ThrowStartPad, a return portal always usable, at least four Stone variants/tier slots and four pools **reusing** systems, not cloned scripts. Set `world.winMultiplier = 3` and `world.skillMultiplier = 2` as placeholder balance knobs, not inferred original values. Show these multipliers on teleport/World info screen.

**Implementation:** For MVP worlds occupy separate areas of the same Workspace with origins spaced >=1500 studs apart, allowing `PivotTo`/CFrame transfer and eliminating cross-place persistence bugs. WorldConfig supports `mode = "samePlace"` now and optional `mode = "otherPlace"` + verified PlaceId later; only then use server-side `TeleportService:TeleportAsync` and document its test limitations.

### 6.6 Map graph / movement expectations

```
           [ Water Throw Canal / Distance Milestones ]
                              |
                    [ THROW START PAD ]
                              |
         [ 7 Training Pools ] -- [ 10 Stone Pedestals ]
                              |
  [ Leaderboards ] -- [ Spawn/Concourse ] -- [ Egg / Pets ]
            [ Gift Chest ]            [ World 2 Portal ]
```

From spawn: an untrained user can reach a training pad in <15s, the Throw pad in <25s, and the first Stone purchase in <25s by walking; do not force world gate interactions before tutorial completion. Spawn camera should reveal at least one training lane, Stone pedestals, and the Throw direction sign.

### 6.7 Building hierarchy and tagging

`Workspace.Worlds.World1` contains `Geometry`, `SpawnPoints`, `TrainingZones`, `StoneStands`, `ThrowZones`, `Portals`, `RewardStations`, `Leaderboards`, `Decorations`. Use `CollectionService` tags such as `TrainingZone`, `StoneStation`, `ThrowStation`, `WorldPortal`, `ClaimChest`, `EggStand`. Each interactive Model has Attributes `Id`, `WorldId`, `InteractionRadius`, optionally `DisplayName`. All IDs cross-reference config and must pass initialization assertions. Server binds interaction on tags and Attributes; no copy-pasted station scripts allowed.

**Physics/collisions:** All static ground/stairs anchored. Pad triggers invisible anchored CanCollide=false parts. World decorative models collision group `Decor`, noncollidable where appropriate. Portals must teleport to safe anchored floor after server validation; protect against repeated touched events using cooldown. Use `ProximityPrompt` with KeyboardKeyCode E plus client touch buttons as applicable; server validates prompt activations too.

---

## 7. UI VISUAL SYSTEM — PIXEL-LEVEL INTENT, NOT FRAGILE PIXEL COORDINATES

**Aesthetic:** Saturated, playful, high-contrast, big white text with 2–3 px charcoal strokes (scaled with UI), cheerful iconography, thick black borders around shop panels, `UICorner` radius 10–20 px, small gradients and inner highlights. The reference is intentionally bold/child-friendly, not minimalist enterprise UI.

### 7.1 UI tokens to define once

| Token | Value / behavior |
|---|---|
| `COLOR.WHITE` | `#FFFFFF` primary headings |
| `COLOR.INK` | `#11131C` high-contrast outline |
| `COLOR.YELLOW` | `#FFD92F` costs/rewards |
| `COLOR.GREEN` | `#53E520` available/success, with outline |
| `COLOR.RED` | `#F92942` locks/errors/close buttons |
| `COLOR.BLUE` | `#31B9FF` XP progress |
| `COLOR.PURPLE` | `#A367FA` premium/skip/rebirth |
| `COLOR.GOLD` | `#FFB90D` Wins/trophies |
| `PANEL_DARK` | Semi-opaque `#111B2B` at ~70–80% opacity |
| `FONT` | Roblox-supported heavyweight rounded/bold font with fallback; never assume custom imported font available |
| `TEXT_STROKE` | Dark stroke `0.0–0.2` TextStrokeTransparency; readable at 720p |
| `BUTTON` | Rounded filled rectangles with strong edge/hover/pressed state and 44×44 px equivalent touch targets |
| `FILL_PERCENT` | Clamp 0..1 and animate with `TweenService` <=0.25s except special transitions |
| `MODAL` | Bounded at 88% viewport width/85% height, scrollable interior; blur overlay optional |
| `ICONS` | Original/or license-safe flat cartoon assets, 1:1 PNG where suitable; temporary geometric placeholders permitted |

### 7.2 Layer architecture

Create `PlayerGui/PlusOneGui` (`ScreenGui`, `ResetOnSpawn=false`, `IgnoreGuiInset=false`) with ordered frames:

```
PlusOneGui (ScreenGui)
  SafeAreaRoot
    TopLeftActions (Settings, Roblox core UI spacer, chat-safe)
    TopRightActions (Daily Rewards, Update Log)
    LeftNav (Shop, Rebirth, Pets, Trails, Inventory, Gifts)
    BottomLeftStats (Rebirth icon+count, Trophy icon+Wins, Friend Boost)
    CenterFeedback (floating +Skill, +Wins, Level Up, notifications)
    BottomProgression
      CurrentSkillDisplay (lightning icon + large Skill)
      CurrentZoneMultiplier (xN label)
      LevelBar (Level X, XP current / needed, fill)
      QuickSkillProducts (3 Robux quantity cards)
    ContextPrompt (interactions and distance/result)
    ModalLayer (one visible modal at a time)
    ToastLayer
    TutorialLayer (first-time spotlight)
```

Do **not** position own menu buttons on top of Roblox's menu/chat/emotes controls; obey UI inset/safe bounds, and do not hide core controls. Use `UISizeConstraint`, `UIListLayout`, `UIGridLayout`, `UIPadding`, `UIAspectRatioConstraint` as appropriate. ModalLayer z-index above HUD; modal close button always hittable.

### 7.3 HUD desktop layout (1920×1080 reference target)

- Bottom-left stats group anchored approx 2% viewport from left, 13–24% from bottom depending safe region. It contains pink/cyan rebirth icon + bold integer, gold trophy + Wins total, third line `Friend Boost +0%` with green plus/info action. Three compact rows, left-aligned. It updates without opening a modal.
- Left navigation vertical 2-column or 1-column layout, near X 1–2%, Y ~38–65%; 70×70 nominal cells with icon centered and text `Shop`, `Rebirth`, `Pets`, `Trails`, `Inventory`, `Gifts`. Distinct red notification dots only when genuinely claimable/unseen.
- Rebirth nav button can show a subtle percentage ring/badge. It should reflect `level / cap`, not hardcoded 72%.
- Bottom center skill `⚡ 66.8K SKILL` near 2% above bar, current multiplier below/adjacent, bar width ~38–45% viewport and height ~64px at 1080 reference, round corners and stud texture optional.
- Level bar displays `LEVEL 58` left, `1.44K / 7.12K` right. Fill is bright azure over pale patterned inactive strip. Ensure label still legible on progress background.
- Directly under bar, three quick-buy card buttons `+10K`, `+100K`, `+1M Skill` with product icons and Robux prices. Cards 1:1.8–2.2 proportions; use config instead of placeholder prices if product not configured. Do not interfere with Roblox's bottom safe area.
- Small floating `+285` lightning pickups over current pad appear near avatar in worldspace or center feedback; fade upward 0.65–0.9s and combine multiple events if flooding.
- Top-left Settings gear not overlap Roblox core UI; top-right Daily and Update icons use a compact pill/group.

### 7.4 Mobile adaptations

- Portrait: vertical layout prioritized. Nav collapses to one button opening a 2-column drawer; bottom progression bar limited to ~94% width; quick-buy row becomes horizontal scroll or a `+` button opening a shop subset. HUD counters above the bar, never over gameplay primary interaction. Top actions are 44px+ touch targets and respect notch/safe areas.
- Landscape smartphone: icon-first nav with reduced margins; level bar max 45–55% width, font min 12–14 px effective after scaling. Do not let large mobile labels spill into the camera.
- Gamepad: all menus navigable using selectable buttons (`Selectable=true`, next-selection configured where needed), close with B, submit with A. Focus ring visible and high contrast; never require hovering.
- Touch interaction: `ProximityPrompt` natively supports mobile; a custom large bottom `THROW` button can appear while within Throw pad, but must trigger server validation.
- Text scaling: `TextScaled` with bounds or `UITextSizeConstraint`, do not use infinitely shrinking unreadable text. Long translated text should wrap and scroll.
- Accessibility: icons must include text on important actions; do not communicate Locked/Unlocked only by red/green; camera shake and particle settings must work; flash animations restrained.

### 7.5 Modal behavior standard

Only one large modal may be open at a time; opening another closes previous cleanly. Outer background dims gameplay ~35% (or blur lightly) but player remains physically safe. `X` close always top-right, keyboard Esc/B supported; clicks outside optionally close only nontransactional dialogs. UI buttons debounce while awaiting server response. Monetary buttons must distinguish `Buy 32 Robux` from `Buy for 32 Wins`; both amounts retrieved from proper authoritative source. A failed purchase shows specific reason and does not optimistically modify stats.

### 7.6 Required screens and components

**Shop (Scrollable):** title + bag icon, `Packs` row/cards (Starter, Demon), `Game Passes` grid (2x Skill, 2x Wins, Pool access, Auto Win, Auto Rebirth), `Skill Products` 10K/100K/1M, `Wins Products` optional, `Pets / Eggs` optional, optional limited items with factual availability. Each card has icon, name, concise contents, ownership/buy state, and Robux price returned from marketplace. Do not display a slashed former price unless an actual validated promotion exists.

**Rebirth:** before/after multiplier comparison, red exact reset disclosure, progress bar, `Rebirth` or disabled `Reach Level N`, optional Skip purchase. HUD still counts wins while modal closed.

**Daily Rewards:** 7 panels in 4+3 grid, days numbered, Day 7 featured colorful gradient; grayed previous claimed, brightly highlighted available day, future locked, countdown formatted HH:MM:SS, claim CTA. Timer derived from trusted server `nextClaimAtUtc`, not independently resetting client countdown. Example reward manifest in §12.

**Settings:** Sound Effects 0–100 slider, Music 0–100 slider, Camera Shake on/off, Effects on/off, Hide HUD on/off. Add Reduce Motion and High-Contrast Text if feasible. `Hide HUD` keeps a small restore button and core/throw controls accessible; it does not hide Roblox safety/core menu UI. Use saved client preferences.

**Update Log:** list of dated `Version` entries, short bullet-like lines `World`, `Stones`, `Eggs`, `Pets`, `Boost Pools`; only list real shipped features. Latest update highlighted; fallback `No updates yet` valid for starter template.

**Pets:** egg opening view with model, coin Win cost, rarity table and disclosed odds (if used), equip slots, multipliers, cosmetic preview. Opening should be skippable animation after result authoritative. No pet gambling-like paid mystery without careful platform compliance; base eggs purchasable with Wins.

**Trails/Inventory:** owned entries, icon preview, Equip/Unequip; cosmetic trails persist through death and rebirth; equip exactly one trail at a time, pets default max three. Tooltips explain actual bonuses.

**Playtime Gifts:** timed slots, progress countdown, green Claim only when time met, red dot when claimable. All awards server-verified against active session; do not award offline time by default.

**World Gate Dialog:** `Palm Beach`, `Requires 100M Skill`, player's current Skill, `Enter` enabled if threshold met, otherwise `Need +X Skill`, plus `Back`.

**Leaderboards:** actual player rows `#`, username, formatted number, optionally thumbnail; safe scrolling 10–20 rows; error/empty states and refresh timestamp. Do not fill top leaderboard with fake users, except clearly labeled Studio demo mock data in test mode.

---

## 8. USER JOURNEY AND FIRST-TIME TUTORIAL

**New user first minute:**

1. Player appears in World 1 spawn. Minimal toast: `Train to earn Skill!` and arrow points toward basic aqua pool. A `Skip Tutorial` button exists.
2. Walk onto pool. `Training: 1x` pill appears; Skill ticks every ~1 sec with a small upward lightning `+1` effect and bar movement. Explain `Higher stones = more Skill every second`.
3. After ~5 Skill, direct player to orange Throw Zone; first Throw prompt appears. Throw visually travels 28+ studs and pays at least 1 Win (formula in §5).
4. HUD trophy count animates upward. Overlay points to +3 Stone cost 2 Wins. If player has 1 Win, suggest one more throw rather than forcing purchase.
5. Buy +3 Stone from pedestal. Tooltip: `Your base Skill gain is now +3 per tick!`; return to pool. Observe visible increase (no paywall).
6. Rebirth button demonstrates progress percentage but doesn't obstruct; tapping explains Level goal and x2 future benefit.
7. Daily Reward button unobtrusively indicates available Day 1; claim is optional. Shop and gifts never pop open automatically during this flow.
8. When tutorial flags completed, save them permanently. Revisits show normal HUD, not forced walkthrough.

**First 10 minutes:** From free resources alone, players should make several Stone purchases and move noticeably toward Level 50. Balance test must verify meaningful upgrades in a 10–15 min session with average user behavior. If starting economy is too slow under exact initial formulas, adjust **XP scale or training/base payout** in central config; do not secretly grant currencies from UI.

**Progression messaging:** Surface one next recommended milestone: `Next stone +12 at 40 Wins`, `Rebirth unlock at Lv 50`, or `World 2: 100M Skill`. Avoid overwhelming first-time user with all 16 systems.

---
## 9. PLAYER DATA MODEL, SCHEMAS, AND STATE TRANSITIONS

### 9.1 Profile schema (`schemaVersion = 1`)

Implement a single strongly validated plain-Luau table per player; dates as UTC Unix seconds; keys as compact strings; inventory items keyed by stable IDs, not model names. Below is a **logical schema** rather than JSON guaranteed import syntax:

```lua
local DefaultProfile = {
    schemaVersion = 1,
    meta = {
        createdAt = 0, lastSeenAt = 0, lastSaveAt = 0,
        migrationVersion = 1,
    },
    economy = {
        skill = 0, lifetimeSkill = 0,
        wins = 0, lifetimeWins = 0,
        robuxSpent = 0, -- observed verified receipts for this game only
    },
    progression = {
        level = 1, bestLevel = 1, levelXp = 0, rebirths = 0,
        currentWorld = "world1", highestWorldVisited = "world1",
        equippedStoneId = "starter",
        ownedStones = { starter = true },
        tutorialCompleted = false,
        tutorialStep = 1,
    },
    inventory = {
        pets = {}, -- uniqueInstanceId -> {speciesId, acquiredAt, source, ...}
        equippedPetIds = {}, -- instance IDs, maximum 3 by default
        trailsOwned = {}, -- trailId -> boolean
        equippedTrailId = "none",
        relicsOwned = {}, -- relicId -> boolean
        equippedRelicId = "none",
        consumables = { skillBoost2x = 0, winBoost2x = 0, luckBoost2x = 0 },
        persistentEntitlements = {}, -- e.g. starter pack 2x Skill/Wins; not marketplace pass ownership
    },
    boosts = {
        -- use expiry times, not client-side time count
        skillBoost2xExpiresAt = 0, winBoost2xExpiresAt = 0,
        luckBoost2xExpiresAt = 0,
    },
    rewards = {
        freeCommunityBonusClaimed = false,
        lastDailyClaimAt = 0, nextDailyIndex = 1,
        dailyClaimsTotal = 0,
        -- playtime gift claims are scoped per session by default
    },
    settings = {
        sfxVolume = 100, musicVolume = 100,
        cameraShake = true, effects = true,
        hideHud = false, reduceMotion = false,
        autoWinEnabled = false, autoRebirthEnabled = false,
    },
    purchases = {
        -- recentReceipts acts only as a bounded cache;
        -- durable receipt dedupe requires receipt strategy in §16.
        gamepassEntitlementsCache = {},
    },
    stats = {
        totalOnlineSeconds = 0, totalThrows = 0,
        biggestThrowDistance = 0, totalRebirthsFromSkip = 0,
    },
}
return DefaultProfile
```

**Server transient state** (do not persist): `profileLoading`, `profileDirty`, `sessionLock`, `activeTrainingZone`, `lastThrowAt`, `throwInProgress`, `lastInteractionAtByType`, `sessionJoinMonotonicAt`, `thisSessionActiveSeconds`, `temporaryFriendCount`, `isOnThrowPad`, `isAlive`, and per-player request throttles. Put transient fields in a separate runtime object to avoid leaking them to datastore.

### 9.2 Rules for profile validation/migration

- On load, merge only known keys into a deep copy of defaults; unknown fields logged and either intentionally preserved in `extra` or excluded by documented policy, never unintentionally clobbered.
- Verify all counters finite, >=0, below safe max; counts/rebirths integers, Level >=1, XP >=0 and below threshold after normalization.
- Verify equippedStoneId is owned and config-valid; if invalid use highest valid owned Stone or starter.
- Equipped pets must exist in owned pet instance map, have distinct IDs, respect max equips. Pet bonus types must exist in PetCatalog.
- Trail must be owned or `none`. Premium pool access should be verified by MarketplaceService; do not persist an unsupported `ownsPass=true` as a substitute for Roblox ownership.
- Daily timestamps cannot be in unreasonably distant future; anomalies should be logged and handled safely, not used to issue infinite claim loops.
- Gracefully migrate data when Stone or Pet IDs have been renamed via `MigrationMap`. Never reset entire profiles because a new update added one field.
- Use explicit `schemaVersion`, migration function `vNToNPlus1`, and tests for old profiles.
- On Roblox datastore **load failure**, show `Unable to load your data. Rejoin to protect your progress`; disable purchases and saving rather than treating as a brand-new player.
- On session lock conflict, wait/backoff/perform bounded retry; don't allow two active servers to modify same profile silently.

### 9.3 Replicated client view (minimal)

Clients receive sanitized state:

```lua
{
    version = 104, serverUtc = 1792041000,
    economy = { skill=1250, wins=152, lifetimeWins=721 },
    progression = {
        level=17, levelXp=750, xpToNext=930, levelCap=50,
        rebirths=0, rebirthMultiplier=1,
        equippedStoneId="wood", stoneBaseSkill=30,
        currentWorld="world1", activeZoneId="training_basic",
        effectiveSkillPerTick=30,
        effectiveSkillMultiplier=1,
    },
    entitlements = { doubleSkill=false, autoWin=false },
    rewards = { nextDailyIndex=1, dailyReady=true, dailyNextAt=0 },
    friends = { count=0, skillBonusPercent=0 },
    inventorySummary = { petCount=0, equippedPetIds={}, equippedTrailId="none" },
    options = { autoWinEnabled=false, autoRebirthEnabled=false },
}
```

**Replication:** Initial `GetSnapshot` request after data readiness; thereafter push **deltas** for affected fields at capped rate; UI is never authoritative. Provide `version` increment for transactions and ignore stale/out-of-order deltas on client, or simply publish full snapshots on low-frequency meaningful transitions. For high-frequency 1s Skill increments send grouped at 4–10 Hz max; actually 1 Hz suffices. Do not send full owned pet inventory 10 times/second.

### 9.4 Data ownership table

| Datum | Owner | Saved? | Sent to UI? |
|---|---|---|---|
| Skill / Wins / Level / XP / Rebirth | Server profile | Yes | Yes |
| Ownership of Stones / equipped Stone | Server profile | Yes | Yes |
| Pet instance inventory, equipped pets | Server profile | Yes | Summarized; full in Pet modal |
| World presence | Server transient + saved last world | Yes, validated on load | Yes |
| Active pool overlap | Server runtime | No | Yes |
| Friend count | Server runtime | No | Yes |
| Product/gamepass purchase status | Marketplace + server profile cache | Receipt log yes; pass verified separately | Yes |
| UI animation offsets, mouse hover | Client | No | N/A |
| Player settings | Server persisted or local client saved via server | Yes if configured | Yes |
| Playtime gift progress for this session | Server runtime | No by default | Yes |
| Cumulative time played | Server profile | Yes | Yes |
| Ordered leaderboards | Derived projection from server profile | Separate ordered store | Yes |

---

## 10. NETWORK CONTRACT — REMOTES AND RESPONSE CODES

Create a single `ReplicatedStorage/Remotes` folder with named `RemoteEvent`/`RemoteFunction` instances, initialized exactly once by server bootstrap. These names are examples; avoid per-stone event proliferation. Every client request identifies action by a **server-known ID**, never a currency amount, a final result, a raw CFrame to teleport to, or a multiplier.

| Remote | Direction | Payload | Server validation | Response |
|---|---|---|---|---|
| `GetInitialSnapshot` | Client → Server function | none | loaded session | profile view or `LOADING` |
| `RequestBuyStone` | Client → Server event | `{stoneId:string, requestId:string}` | known ID, near stand, wallet, debounce | result event + deltas |
| `RequestEquipStone` | Client → Server event | `{stoneId:string}` | owned ID | equip result |
| `RequestThrow` | Client → Server event | `{worldId:string, throwId:string}` | live player, at pad, cooldown, world | `{distance,wins,...}` |
| `RequestRebirth` | Client → Server event | `{requestId:string}` | current level cap | mutation result |
| `RequestWorldTravel` | Client → Server event | `{worldId:string}` | valid portal proximity, Skill gate | travel result |
| `RequestClaimDaily` | Client → Server event | `{requestId:string}` | server time and saved daily state | reward result |
| `RequestClaimPlaytimeGift` | Client → Server event | `{giftId:string}` | cumulative this-session time, claimed | reward result |
| `RequestCommunityReward` | Client → Server event | `{}` | claimed flag, verified group if configured | reward result |
| `RequestEggOpen` | Client → Server event | `{eggId:string, quantity:integer}` | wallet, limit, correct location | authoritative pet award |
| `RequestEquipPet` | Client → Server event | `{petInstanceId:string}` | owned, max equips | equip result |
| `RequestEquipTrail` | Client → Server event | `{trailId:string}` | owned | equip result |
| `RequestUseBoost` | Client → Server event | `{boostId:string}` | inventory count, cap | boost result |
| `RequestSetOption` | Client → Server event | `{key:string,value:boolean|number}` | whitelisted key/value | acknowledgement |
| `RequestToggleAutomation` | Client → Server event | `{key:string,enabled:boolean}` | owns required pass | automation state |
| `StateUpdate` | Server → Client event | `{version,...delta}` | server emits | none |
| `ActionResult` | Server → Client event | `{requestId,action,ok,code,data?}` | server emits | none |
| `SystemToast` | Server → Client event | `{kind,formattedKey,params}` | server emits | none |

**Remote request IDs:** Accept small alphanumeric/UUID-like strings <=64 chars for deduplication of transient client retransmits. Never trust them as proof of payment; maintain bounded recent request ID caches per player and action. Do not allow unlimited unique IDs to flood memory. If request callback throws, send `SERVER_ERROR` without raw internal stack to clients; log structured server error.

**Rate limits (initial):** `RequestThrow` one per 3s; Stone buys max 3/s burst 5; equipment 3/s; reward claim 1/s; modal options 5/s; snapshots one per 2s. A `ProximityPrompt` activation is likewise untrusted input. Limits are per player, enforced before expensive operations; malicious activity does not reset other players' state.

**Payload validation:** `typeof` checks for type; strings <=64 chars; quantity whitelist `{1,3}` or valid set; reject nil/NaN/infinite/huge values, oversized tables, and Instances from clients unless narrowly needed. Lookup server config by ID; never accept `cost`, `baseSkill`, `winsEarned`, `distance`, `levelCap`, or `expiry` from client.

**Client UX:** While server checks an action, show disabled spinner or brief “Processing...” indicator; on result update from authoritative state; provide meaningful retry on transient failure. Avoid duplicate popups if same request returns twice.

---

## 11. MONETIZATION CATALOG AND PURCHASE ENGINE

All Robux prices, descriptions, images, and IDs must be editable. `Enabled=false` whenever ID not supplied; UI clearly says `Unavailable` rather than pretending a user spent Robux. Roblox purchases **must** use its official marketplace prompts and fulfill through server-side verification. No custom hidden charges.

### 11.1 Permanent Game Passes (non-consumable, owned once)

| Internal key | Visible name | Behavior | Suggested UI |
|---|---|---|---|
| `doubleSkill` | `2x Skill` | Global x2 Skill earnings while owned | Lightning card |
| `doubleWins` | `2x Wins` | Global x2 thrown Wins | Trophy card |
| `pool3x` | `3x Training Pool` | Unlocks navy lane only | Navy lane/card |
| `pool15x` | `15x Training Pool` | Unlocks gold lane only | Gold lane/card |
| `pool50x` | `50x Training Pool` | Unlocks neon lane only | Neon lane/card |
| `autoWin` | `Auto Win (Online)` | Server payout every configured 12s while online/train eligible; opt-in | Auto Win card |
| `autoRebirth` | `Auto Rebirth` | Automatically rebirth at cap when opt-in | Auto Rebirth card |
| `extraPetSlots` | `+2 Equipped Pets` | Raises equip cap from 3 to 5 | Pet card |
| `fastEgg` | `Fast Egg Animation` | Cosmetic quality-of-life | Egg card |

**Price policy:** The screenshot depicts various numeric Robux prices (e.g., 5, 48, 80, 120, 200, 480), but those values **must not** be represented as live prices for the new game without a corresponding product configured by the developer. `SuggestedDisplayPrice` is only a UX test fixture. Real price should be obtained from `MarketplaceService:GetProductInfo...`/appropriate current API with `Enum.InfoType.GamePass`, wrapped in `pcall`, and cached with a reasonable refresh; handle personalized pricing. For pass purchase, `PromptGamePassPurchase` from client UI as supported, then **server** listens for `PromptGamePassPurchaseFinished` and/or refreshes `UserOwnsGamePassAsync` before granting in-session benefits. On join always verify ownership. Avoid polling ownership every second.

### 11.2 Developer Products (consumable/repeatable)

| Internal key | Grant | Notes |
|---|---|---|
| `skill10k` | Add exactly 10,000 Skill plus linked XP grant | Bottom quick card |
| `skill100k` | Add 100,000 Skill plus linked XP grant | Bottom quick card |
| `skill1m` | Add 1,000,000 Skill plus linked XP grant | Bottom quick card |
| `winsSmall` | Optional configured Wins quantity | Shop section |
| `winsLarge` | Optional configured Wins quantity | Shop section |
| `skipRebirth` | Complete exactly one reset-and-rebirth transaction | Prompted only with reset warning |
| `starterPack` | One-time entitlement+benefits via **receipt**, only if server enforces one-time consumption | See below |
| `demonPack` | Configurable premium pack | See below |
| `gift1`, `gift2`, `gift3` | Clearly specified gifts / products | Require IDs to activate |

**When a pack contains permanent entitlement like a pass:** Prefer a Game Pass for the permanent portion, with clear bundle fulfillment semantics that are feasible and authorized. Never promise ownership of a separate Roblox Game Pass by awarding a profile boolean. For convenience, represent starter/demon packs as **one-time Developer Products** granting recorded permanent **in-game entitlement flags** + specified consumables and pets within this experience, not actual marketplace passes. On repeat attempts, UI says `Already Claimed` and does not prompt (but receipt processor remains idempotent). If one-time developer product prompt cannot be technically prevented through external store surfaces, configure listing and policy accordingly; do not take Robux and deliver nothing on an accepted repeat receipt. A safer variant is to grant repeatable equivalent consumables on subsequent purchases, clearly disclosed and approved by game owner.

### 11.3 Default bundle composition (mutable data, examples)

**Starter Pack (owner-requested core benefit):** Permanent **2x Skill + 2x Wins**, plus 1 exclusive `starterNeko` pet, `100,000 Skill` (linked XP), one `skillBoost2x` potion, and one rebirth token or immediate bonus Rebirth where explicitly disclosed. The screenshot `x30` next to a pet is ambiguous: default to **one pet**, not thirty without owner confirmation. **Important implementation:** A Developer Product cannot magically grant ownership of separate marketplace Game Passes. Store bundle-granted `bundleSkill2x` and `bundleWins2x` as permanent **in-game entitlement flags** in `inventory.persistentEntitlements`. If a player also owns the separately sold doubleSkill/doubleWins Game Pass, the two sources **do not stack**: each category remains 2x total, implemented as `max(verifiedPassMultiplier, permanentBundleMultiplier)`, not 2×2=4x. The shop must disclose the no-double-dipping rule and show already-included benefits. If the pack grants an immediate rebirth and current-life Skill, **rebirth first**, then grant purchased Skill, or else Skill would be instantly wiped. A rebirth token avoids surprise resets and is the safer default; implement token schema and redemption explicitly before enabling. Every pack item and grant order must be clear in the purchase card and receipt.

**Demon Pack:** 1 `demonCub` pet, 3 assorted potions, one unique trail, and 1 rebirth token (token is a consumable redeemable by explicit player input rather than immediate reset, recommended). If granting any tokens, add schema fields and explicit redemption rules before shipping.

**Do not display false sales:** A struck-through `R$199` over `R$32` must only appear if legitimately supported by an actual promotion/previous price and reviewed for platform compliance; default no slash, no urgency countdown, no false stock. If an item is “limited,” actual supply/access limits and expiration must be enforced by the server and communicated accurately.

### 11.4 Correct developer product receipt processing

Use **one designated server purchase handler**. Roblox `MarketplaceService.ProcessReceipt` must not be assigned by multiple scripts; confirm up-to-date Roblox guidance if newer binding alternatives are used. Required steps:

1. Receive receipt containing `PurchaseId`, `PlayerId`, `ProductId`, and recorded price information where available.
2. Validate supported ProductId against `ShopCatalog`, identified user and currently loadable profile. If player isn't present/profile unavailable, return `NotProcessedYet`.
3. Check durable dedupe for the unique `PurchaseId` (not just product ID). A duplicate receipt already committed returns `PurchaseGranted` without re-awarding.
4. Execute **atomic durable grant** strategy. Prefer `UpdateAsync` on the player's primary profile key that checks whether `PurchaseId` already granted and, if new, merges precisely the grant and marks receipt completed in the same stored profile transaction. Compute deterministic reward solely from a catalog version plus receipt (see versioning issue below). Avoid yielding inside `UpdateAsync` transform.
5. Only after verified durable commit, return `PurchaseGranted`. On datastore/transient error, return `NotProcessedYet` and retry later. If profile temporarily offline, receipt should still be safely fulfillable by the chosen architecture; do not rely exclusively on a mutable in-memory player object.
6. Reconcile/update currently loaded profile safely without overwriting newer in-session progress. Receipt commit and normal autosave must cooperate through a single transaction/revision system. **Do not** implement independent profile `SetAsync` and receipt `UpdateAsync` that race each other.
7. Log `PurchaseId` (redacted where logs are public), ProductId, grant type, result, server transaction ID, and official Robux price if available. Increment `robuxSpent` exactly once per receipt, using receipt's actual price where the API provides it; if price unavailable, do **not** fabricate a value.

**Receipt-history scaling:** An infinite array of `PurchaseId`s bloats profile size. Build a finite history plus separately durable receipt-key ledger **or** a profile-integrated bounded receipt index with proven retention/deduplication under Roblox retry rules. Document strategy and failure cases. Do not blindly prune IDs while Roblox could re-deliver a previously acknowledged receipt; if unsure use separate durable dedupe records keyed by PurchaseId and design crash-atomicity carefully (or use a maintained profile/receipt library with verified guarantees). A two-key grant/marker scheme without atomicity can double grant after a crash and is **not automatically correct**. Favor a unified transaction with monotonic revision and idempotence, or document/verify a reputable hardened solution.

**Catalog versioning:** Receipt may arrive after items change. Snapshot a `grantCatalogVersion` for listed ProductIds or maintain a stable versioned award map so old purchases aren't silently remapped to less valuable products.

### 11.5 Paid +Skill packs and levels

Upon durable `skill10k` receipt, add Skill 10,000 and XP 10,000 × `XPPerSkillAwardScale` (unless clearly configured otherwise); apply level-up calculation and cap. Do not multiply paid pack awards by training multipliers, unless the advertised pack explicitly promises multiplication. Bonus should appear in HUD and leaderboard with appropriate anti-overflow clamp. A level-capped player can buy Skill; Skill increases but XP remains capped until rebirth. Clearly disclose that rebirthing will reset purchased current-life Skill, including before purchase confirmation where practical.

### 11.6 Shop UX and ownership states

- `Owned` (green check) for permanent pass, disables purchase.
- `Buy R$N` for a valid configured product with fetched live price.
- `Unavailable` when ID invalid/price failed; retry prompt only after successful metadata fetch.
- `Processing...` during prompt resolution or backend await; client cosmetic state only.
- `Successfully Purchased` after server acknowledges entitlements/grant via snapshot.
- Product detail must state whether consumable/current-life/permanent. Rebirth warnings must not be buried.

---

## 12. DAILY REWARDS, PLAYTIME GIFTS, COMMUNITY CHEST

### 12.1 Seven-day daily reward schedule

| Day | Default reward | Implementation details |
|---|---|---|
| 1 | 1 × 2x Skill Boost (15 min) | Consumable item, not immediate activation |
| 2 | 1 × `fortuneNeko` pet | Owned unique instance; fallback if pet ID missing: named placeholder, not silently no reward |
| 3 | 1 × 2x Wins Boost (15 min) | Consumable |
| 4 | 2 × 2x Luck Boost (15 min each) | Influences egg rarity if eggs enabled |
| 5 | 3 × 2x Skill Boost (15 min) | Consumable |
| 6 | 3 × 2x Wins Boost (15 min) | Consumable |
| 7 | 1 × `shootingStarTrail` cosmetic | Unique trail; if already owned grant documented alternate e.g. 3x boosters or duplicate currency |

**Cycle policy:** Login and claim once per **24 hours**. `nextDailyIndex` moves 1..7 then resets to 1 for the next cycle. Missing days does **not** reset the streak by default; players can resume next unclaimed day. This is intentionally gentler than punitive daily streak resets. The visual countdown reflects `lastDailyClaimAt + 86400`. Day 1 is claimable on first load. All timestamps measured server-side `os.time()`; client timer display receives absolute UTC next time. Consecutive clicks grant once. Daily award and claim timestamp must be saved as one transaction. When already claimed, show exact time remaining, not `Claim Now`.

**Bad network:** If claim save fails, return `TRY_AGAIN` and preserve claimability/previous durable state with no duplicate items; prefer transactionally durable grant + flag. If the server mutates memory first and loses connection before save, know how retry/rejoin will reconcile. Ensure exactly-once gameplay outcome as practical under platform storage semantics.

### 12.2 Playtime gifts (session-based, configurable)

| ID | Required active session time | Reward |
|---|---:|---|
| `t02` | 2 minutes | 100 Wins |
| `t05` | 5 minutes | 1 Skill boost |
| `t10` | 10 minutes | 500 Wins |
| `t15` | 15 minutes | 1 basic pet egg ticket |
| `t30` | 30 minutes | 1 double-Wins boost |
| `t60` | 60 minutes | 1 exclusive trail color / alternative if owned |

Server tracks online elapsed time using a monotonic timer, pauses eligible time when player disconnects and never trusts client-supplied seconds. For first template version, gifts reset each new server session; if experience policy should be daily per user, change to UTC date scoping in a saved profile (configuration flag) and document change in UI. A user can claim gifts in any order after required time; claiming at 60 min does not erase 2-min gift. Gift IDs prevent repeated grants. UI shows `Claim in mm:ss` or `Claim`.

### 12.3 Community/free chest — implementation honesty

Screenshot has a `CLAIM` chest and modal asking players to **Like, Favorite, and Join Community**, promising +10,000 Skill. Roblox group membership can be checked with `Player:IsInGroupAsync(groupId)` (with cache limitations), but **a reliable sanctioned in-experience API for individually verifying likes/favorites should not be assumed**.

**Template default:** Offer a one-time `Welcome Gift` of +10,000 Skill claimable from chest for everyone, with voluntary prompts `Like/Favorite this experience` and `Join our community` as separate non-blocking informational affordances. If game owner supplies valid GroupId, an additional **verified group-only cosmetic reward** can be enabled and checked server-side via `IsInGroupAsync` (with retry/rejoin messaging). Never display `Verified like!` or require users to claim they performed an action the game cannot verify. Check current Roblox platform promotion/community policies before activating any incentive tied to social engagement.

**Chest interaction:** glowing ring + red/gold chest + large `CLAIM`; prompt within 16 studs; open modal with actual reward and once-only status. Claim request validated server-side. On success set `freeCommunityBonusClaimed=true` and apply 10K Skill/linked XP atomically. On repeat display `Already claimed`. Visible glow dims after claim. Gift popup automatically opens only on direct user action.

### 12.4 Friend boost

Count friends among players in **same active Roblox server** using `Player:IsFriendsWithAsync(otherUserId)` or verified current API and cache results with join/leave refresh. Each friend +10% Skill up to +50%. Update when another player joins/leaves; recompute server-authoritative `FriendMult` and HUD line `Friend Boost +20%`. Clicking green `+` shows `Invite a friend — each friend in this server grants +10%, maximum +50%.` Use official invitation functionality only if available and permitted; disabled fallback otherwise. Never infer friends solely from user names or local client declarations.

---

## 13. PETS, EGGS, TRAILS, RELICS, AND BOOSTS

These are P1/P2 extensibility modules, but at least one simple egg and pet equip must work in a feature-complete launch template.

### 13.1 Egg and pet catalog

Default egg `Harbor Egg`, cost 150 Wins, 4 pet species:

| Pet | Chance (base) | Skill bonus | Win bonus | Rarity |
|---|---:|---:|---:|---|
| `pumpkinBunny` | 55% | +0.10 | +0.00 | Common |
| `shellKitty` | 30% | +0.20 | +0.00 | Rare |
| `seaBat` | 12% | +0.30 | +0.05 | Epic |
| `royalCrab` | 3% | +0.50 | +0.10 | Legendary |

Probabilities sum to exactly 100% per base egg. `2x Luck` modifies weight distribution with a **documented** algorithm, not simply doubling all probabilities (which cancels out). Example: multiply Rare weight by 1.25, Epic by 1.5, Legendary by 2.0 and renormalize; disclose odds in egg UI when required under Roblox rules. The catalog must support `weight`, rarity, pet model, display/icon, skill/win bonuses, collection entry, level if later implemented.

**Egg opening operation:** validate config, world/stand distance, sufficient Wins and inventory capacity; decrement Wins and use server RNG, grant a unique pet instance ID, in one serialized in-memory transaction; save; then reveal server-issued pet ID/species to client for animation. Duplicate `requestId`s may not charge twice. Multi-open x3 requires pass or configured unlock and charges cost three times; either award all three together or none (unless specifically documented partial). Use `Random.new()` server-side; seeded for deterministic test harness only.

**Pet equipping:** Max 3 pets base, 5 with purchased pass; identical pet species can equip if distinct instances. Additive bonuses across equipped pets, multiplicative with other categories. Server recomputes Skill/Win multipliers on equip/unequip. Pets float/follow player client-side with a budget-aware orbit, no real server collision or pathfinding per pet. 16-player server with 5 pets each must remain performant; throttle remote pet VFX and hide distant pets.

**Inventory:** sort equipped first, then rarity, then newest; show actual value; allow equip, unequip, delete with confirmation. Deletion is irreversible, so protect favorite/locked pets; optional keep default no-delete to prevent accidental loss.

### 13.2 Trails

Trails are owned cosmetic `trailId`s in inventory; each uses 2 attachments on avatar `HumanoidRootPart` or appropriate limb, plus Roblox `Trail` instance with original art/Gradient. Respawn/rebirth reapplies equipped trail. Default `none` and `shootingStarTrail` daily Day 7 reward; additional 3 trail variants available by Wins or playtime. No trail should affect physics or grant undisclosed stat bonuses.

### 13.3 Relics (optional)

3D pedestals for `Reaper Relic`, `Shooting Star Relic`, seasonal visual items. The screenshot shows a `Reaper Relic` with huge permanent-looking stock/Robux pricing. In this original template, `reaperRelic` should be a **disabled example** until a valid product ID and owner-approved grant definition exist. If enabled, clearly disclose whether relic adds a Skill multiplier or purely cosmetic effect; if advertised as stock-limited, implement genuine cross-server stock accounting with robust claim concurrency (or omit stock entirely). Never show `ONLY 560` or “ALWAYS 200% BETTER” based on invented stock/performance claims.

### 13.4 Boost consumables

Boosts are stored as **counts** and active absolute expiry timestamps. `Use Boost` deducts one on server and sets expiry. Default stacking rule: if same boost active, **extend** existing expiry by its duration (e.g., now+15m becomes expiry+15m), preserving value; do not square multiplier by using multiple potions. Different types (Skill, Wins, Luck) can run concurrently. On reconnect, absolute expiry naturally continues; if the owner wants offline-paused durations, switch to saved remaining-seconds logic and robust session tracking instead. Display icons with MM:SS timers and active x2 amount; if expired, no multiplier.

### 13.5 Reward dispatcher

Implement one `RewardService.Grant(profile, rewardSpec, context)` called by Daily, playtime, chest, pack receipts, and quests. Types: `skill`, `wins`, `rebirth`, `pet`, `trail`, `boostCount`, `relic`, `eggTicket`, `composite`. Reward service validates type, finite values, ownership duplicates, safe caps and transaction context; **never** accepts arbitrary reward spec from clients. Composite rewards must either succeed as one serialized transaction or return a precise partial-failure recovery state with no currency loss.

---

## 14. LEADERBOARDS, SCOREBOARDS, AND SOCIAL PROOF

### 14.1 `leaderstats` vs physical global boards

Add server-created Roblox `player.leaderstats` with concise integer-compatible values `Rebirths`, `Wins`, `Skill`, `Level` as useful for the standard player list; where numbers may exceed Roblox IntValue safe ranges choose appropriate Value types/display policy. Physical global boards are **separate** from local leaderstats and sourced from OrderedDataStores.

Default physical boards (4 shown prominently; optional fifth):

1. `Top Level` — use highest Level achieved (`bestLevel` stored in profile; add field).
2. `Top Time Played` — totalOnlineSeconds (display e.g. `114h 30m`).
3. `Top Robux Spent` — verified Robux spend *within this universe only*, no fabricated cross-game totals; if unavailable disable board with `Coming Soon`.
4. `Top Wins` — lifetimeWins so spending never lowers historical rank.
5. Optional `Top Rebirths` — total rebirth count.

**OrderedStore mechanics:** Server periodically projects modified profile scores to store, not every training tick. Use separate store keys with versioned names and userId string keys, no personally sensitive data. `GetSortedAsync(false, 10–20)` with proper pcall/backoff and API-budget awareness; cache results for at least 120s; cap/name retries and never loop every render frame. Name/thumb fetching can fail, use username fallback and place silhouette. `Top Robux Spent` updates after verified receipt; do not use client-supplied purchases.

### 14.2 Board models

Each board ~35 studs wide × 26 high, wood/orange thick border, green panel interior, 3D `SurfaceGui` with `Top Level` white header, columns for rank/avatar/name/value; 10 rows, dark alternating bands, accents for top 3 gold/silver/bronze. A subtle tall cyan/light beam behind boards, not a photosensitive strobe. Place in lobby with good line of sight and readable camera-facing surface at standing distance. When data unavailable show `Leaderboard updating...` or `No entries yet` in actual UI—not fictional accounts.

### 14.3 Anti-abuse

Do not allow Studio test profiles to leak into public boards; use separate datastore names/test namespace. Don't leak private receipt IDs or user account metadata into displays. Validate extreme scores, clamp within safe range, record abnormal growth in internal logs and throttle leaderboard projection. If a user departs before score projection, prioritize save then write a leaderboard update when feasible; eventual consistency is acceptable.

---

## 15. WORLD SYSTEM AND CONTENT EXTENSION API

**Goal:** Another builder can add World 3 by data/config + one builder module, rather than duplicating logic. Each world defines `id`, `displayName`, `themeId`, `requiredSkill`, `origin`, `spawn`, `throwZone`, `trainingZones`, `stoneStationPlacements`, `eggIds`, `winMultiplier`, `skillMultiplier`, `worldPortalLinkIds`, `enabled`.

Example world rows:

```lua
world1 = {
    id = "world1", displayName = "Pumpkin Harbor",
    requiredSkill = 0, winMultiplier = 1, skillMultiplier = 1,
    mode = "samePlace", enabled = true,
    throwLaneLength = 600,
},
world2 = {
    id = "world2", displayName = "Palm Beach",
    requiredSkill = 100_000_000,
    winMultiplier = 3, skillMultiplier = 2,
    mode = "samePlace", enabled = true,
    throwLaneLength = 800,
},
```

**Server enter validation:** Player must be within WorldPortal prompt area, be in source world, target enabled, destination safe, and have `economy.skill >= requiredSkill`; only then set `currentWorld` and move character via `PivotTo`. Portal sign shows `WORLD 2`, `REQUIRES 100M SKILL`, or `ENTER` based on local snapshot. A player is not teleported because they walk into a portal while still loading data. If gating becomes unavailable after a rebirth, return them to World 1 at rebirth. World 2 has always-usable return portal (no Skill check to exit).

**Loading:** For large worlds and mobile, enable `Workspace.StreamingEnabled` if suitable; ensure critical portal and spawn geometry are reliably streamed or loading is handled before teleport. No fall-through on arriving far from loaded geometry: pre-load/persist critical anchored floor, queue optional assets separately, and show overlay while awaiting environment readiness.

**Theme swap example:** Change Skill to `Power`, Wins to `Stars`, StoneStation to `Workout Machines`, Throw to `Race`, World 2 to `Volcano`; same currencies, leveling, rebirth, purchase engine, timers, and UI component library. New action uses `ActionAdapter:ValidateAndComputeReward(player, profile, worldId)` with same server authority and central `ActionResult`, not an unrelated local-script payout.

---
## 16. PERSISTENCE, SESSION LOCKS, RELIABILITY, AND PURCHASE RACES

This section is **release blocking**. A simulator that loses purchased boosts, pets, currencies, or rebirths is not complete.

### 16.1 Datastores and keys

- Main persistent store: `PlusOnePlayerProfiles_v1` (Production); `PlusOnePlayerProfiles_DEV_v1` in a separate Studio/test namespace/universe.
- Key: `p_<UserId>`; no player usernames in keys.
- Profile operations use protected `UpdateAsync` on the authoritative profile record; merges and migrations controlled by version.
- Ordered data stores: `PlusOneTopWins_v1`, `PlusOneTopLevels_v1`, `PlusOneTopTime_v1`, `PlusOneTopRebirths_v1`, `PlusOneTopRobux_v1` (only if implemented).
- Never call datastore write every Skill tick. Default autosave ~90 seconds with jitter and a dirty flag; important state changes request priority saves while respecting per-server and per-key budgets.
- Persistence writes must be serialized per UserId on the server. If a save is pending, another save is coalesced, not allowed to blindly overwrite later state.

### 16.2 Session locking

A player can connect via two servers during teleport/rejoin. Use a proven Roblox profile session manager (for example, an appropriate maintained profile library) or implement a reviewed session lock protocol with server `JobId`, lock acquisition time, expiry/lease, and safe `UpdateAsync` logic. Ensure stale locks can recover after crashes but not by recklessly stealing active sessions. Use a bounded load retry and explicit timeout; while pending, show a Loading/Data Safe screen, not working gameplay on defaults.

**Write condition:** Every save must confirm it owns the session lock and has not lost authority. If a competing server has taken lock, old server must stop awarding/spending and avoid committing stale profile. On release, flush profile, clear lock safely, then disconnect state and player references. On `BindToClose`, issue bounded concurrent save operations with realistic shutdown time; do not use an unbounded loop.

### 16.3 Purchase concurrency

Roblox purchase receipt callbacks are not guaranteed to arrive in convenient order relative to normal autosaves or join/leave. Adopt **one serialized transaction pipeline per player**. A durable receipt mutation must not later be overwritten by an older in-memory autosave. Valid architectures:

**Preferred A — maintained profile manager with receipts:** Use a verified, actively maintained Roblox profile library whose session lock and transaction model are understood. Apply reward, receipt ID, and spend tally in same profile session/durable transaction and checkpoint. Verify its documentation for receipt continuation upon player absence.

**Preferred B — custom single-record profile transaction:** All profile changes, including receipt grants, go through an actor/queue that persists a revisioned profile with `UpdateAsync`, checks unique receipt ID against the same durable record, and merges authoritative state instead of blind table overwrite. The receipt's callback returns `PurchaseGranted` only after successful durable commit of receipt ID + reward. If callback occurs while the player is on a different server, don't grant on the wrong server; return `NotProcessedYet` until safe session ownership can process it. Handle retry across sessions. All non-receipt in-memory transactions must be serialized into this authoritative timeline.

**Do NOT:**

- Set `ProcessReceipt` from multiple places.
- Reward from a client RemoteEvent saying “I purchased.”
- Reward from `PromptProductPurchaseFinished` instead of receipt.
- Rely on `PlayerRemoving` as the **only** saving strategy.
- Return `PurchaseGranted` before persistent reward + idempotency marker succeed.
- Use a separate receipt ledger in one key and prize grant in another key without carefully solving two-key crash races.
- Overwrite the whole latest datastore profile from a stale `profile` Lua table after a product `UpdateAsync` grant.
- Clear a different server's session lock in a cleanup script.
- Create “read failure = new player” behavior.

### 16.4 Save failure and recovery UX

If writes fail transiently, pause expensive grants if necessary and warn `Saving is temporarily unavailable; we are protecting your progress.` Save retry uses exponential backoff with randomized jitter, respecting Roblox budgets; do not spam writes indefinitely. Avoid blocking every simple Skill tick on remote datastore access. If shutdown occurs while save retries are pending, do best-effort flush, log unresolved account/user IDs securely for investigation (not in client-facing UI), and document what players may see. If storage is unavailable at join, reject gameplay as read-only/loading rather than risk loss.

### 16.5 Duplication/conflict test cases

- Two `BuyStone` packets in same frame: one deduction only.
- Two `RequestRebirth` packets: one rebirth only.
- Two Daily claims in same frame: one reward, next timer advances once.
- Product receipt called twice with identical PurchaseId: exactly one item award and one spend increment, both acknowledgments safe.
- Product receipt granted, then old autosave initiated earlier finishes later: the grant must remain.
- Player purchases product during teleport/disconnect: reward eventually granted on safe next load, not lost or duplicated.
- Crash after memory mutation before durable save: do not claim durable purchase success; receipt safely retries.
- Same user joins another server while first server releasing lock: one writable profile only.
- Datastore `GetAsync`/`UpdateAsync` forced failure: UI reports data unavailable and no stale saves destroy prior state.
- Profile migration with removed Stone and absent optional fields: restore via known migration, preserve currency.

---

## 17. ROBLOX PROJECT STRUCTURE, SOURCE TREE, AND CODING CONVENTIONS

### 17.1 Recommended source project layout

```text
plus-one-template/
├── default.project.json                 # Rojo mapping if used
├── README.md
├── IMPLEMENTATION_STATUS.md
├── ASSUMPTIONS.md
├── TEST_RESULTS.md
├── KNOWN_ISSUES.md
├── assets/
│   ├── icons/                           # LICENSED/ORIGINAL game icon exports
│   ├── references/                      # screenshots, not imported as game icons
│   └── audio/                           # permitted audio or empty
├── src/
│   ├── shared/
│   │   ├── Config/
│   │   │   ├── ThemeConfig.luau
│   │   │   ├── EconomyConfig.luau
│   │   │   ├── StoneCatalog.luau
│   │   │   ├── TrainingZoneCatalog.luau
│   │   │   ├── WorldConfig.luau
│   │   │   ├── RewardConfig.luau
│   │   │   ├── PetCatalog.luau
│   │   │   ├── EggCatalog.luau
│   │   │   ├── TrailCatalog.luau
│   │   │   ├── ShopCatalog.luau
│   │   │   └── UpdateLogConfig.luau
│   │   ├── NumberFormatter.luau
│   │   ├── XPFormula.luau
│   │   ├── WorldMath.luau
│   │   ├── Types.luau
│   │   ├── RemoteNames.luau
│   │   └── Signal.luau                 # optional tiny signal utility
│   ├── server/
│   │   ├── Main.server.luau
│   │   ├── Services/
│   │   │   ├── PlayerDataService.luau
│   │   │   ├── SessionLockService.luau # omit if maintained profile lib handles it
│   │   │   ├── CurrencyService.luau
│   │   │   ├── TrainingService.luau
│   │   │   ├── StoneService.luau
│   │   │   ├── XPService.luau
│   │   │   ├── RebirthService.luau
│   │   │   ├── ThrowService.luau
│   │   │   ├── WorldService.luau
│   │   │   ├── PetService.luau
│   │   │   ├── BoostService.luau
│   │   │   ├── RewardService.luau
│   │   │   ├── DailyService.luau
│   │   │   ├── PlaytimeService.luau
│   │   │   ├── CommunityRewardService.luau
│   │   │   ├── EntitlementService.luau
│   │   │   ├── PurchaseService.luau
│   │   │   ├── ReceiptService.luau
│   │   │   ├── LeaderboardService.luau
│   │   │   ├── FriendBoostService.luau
│   │   │   ├── RateLimitService.luau
│   │   │   └── AnalyticsService.luau
│   │   ├── WorldBuilder/
│   │   │   ├── WorldBuilder.luau
│   │   │   ├── World1Builder.luau
│   │   │   ├── World2Builder.luau
│   │   │   ├── TrainingPoolBuilder.luau
│   │   │   ├── StoneStandBuilder.luau
│   │   │   ├── PortalBuilder.luau
│   │   │   ├── ThrowLaneBuilder.luau
│   │   │   └── LeaderboardBoardBuilder.luau
│   │   └── ServerConfig/
│   │       ├── StorageConfig.luau
│   │       └── DevOverrides.luau
│   ├── client/
│   │   ├── Main.client.luau
│   │   ├── Controllers/
│   │   │   ├── HUDController.luau
│   │   │   ├── WorldVisualController.luau
│   │   │   ├── TrainingFXController.luau
│   │   │   ├── ThrowFXController.luau
│   │   │   ├── ModalController.luau
│   │   │   ├── DailyController.luau
│   │   │   ├── ShopController.luau
│   │   │   ├── SettingsController.luau
│   │   │   ├── TutorialController.luau
│   │   │   ├── InputController.luau
│   │   │   └── AudioController.luau
│   │   ├── Components/
│   │   │   ├── UIBuilder.luau
│   │   │   ├── Button.luau
│   │   │   ├── ProgressBar.luau
│   │   │   ├── CurrencyDisplay.luau
│   │   │   ├── Countdown.luau
│   │   │   ├── ScrollCard.luau
│   │   │   ├── ModalFrame.luau
│   │   │   └── Toast.luau
│   │   └── Views/
│   │       ├── MainHUD.luau
│   │       ├── ShopView.luau
│   │       ├── RebirthView.luau
│   │       ├── PetsView.luau
│   │       ├── TrailsView.luau
│   │       ├── InventoryView.luau
│   │       ├── DailyRewardsView.luau
│   │       ├── PlaytimeGiftsView.luau
│   │       ├── CommunityRewardView.luau
│   │       ├── SettingsView.luau
│   │       ├── UpdateLogView.luau
│   │       └── WorldGateView.luau
│   └── tests/
│       ├── Economy.spec.luau
│       ├── XPFormula.spec.luau
│       ├── Rebirth.spec.luau
│       ├── StoneService.spec.luau
│       ├── ReceiptIdempotency.spec.luau
│       ├── ProfileMigration.spec.luau
│       ├── Rewards.spec.luau
│       ├── RateLimits.spec.luau
│       └── ProgressionSimulation.luau
└── tools/
    ├── sanity_check.py                   # project/static checks, no Roblox runtime assumption
    └── export_instructions.md
```

This is a **logical tree**. Files can be combined to avoid boilerplate if responsibilities remain distinct and comprehensible. Do not create dozens of empty module placeholders and call the template finished.

### 17.2 Coding standards

- Prefer `--!strict` where practical, typed module function signatures, no hidden global variables.
- Service modules expose `Init(services)`, `Start()`, `Shutdown()` and explicit public methods. Init dependency graph must not create circular requires.
- No large monolithic `Main` script for everything. Bootstrap services in deterministic order: config assertions → remotes → storage → player data → economy → gameplay → rewards → purchases → world builder → replication → UI-ready signals.
- Use consistent names: `stoneId`, `worldId`, `player`, `profile`, `requestId`, `baseSkill`, `effectiveSkill`, `winsAwarded`.
- Do not use `wait`, `spawn`, `delay` legacy helpers if more reliable `task.wait`, `task.spawn`, `task.delay` are available. Use `RunService`/timed accumulator where sensible.
- Disconnect `RBXScriptConnection`s and clear per-player state on `PlayerRemoving`; handle respawns, reparenting, and destroyed Instances.
- Use `CollectionService` for station discovery. Handle dynamically added tagged instances via signals as well as initial enumerations; reject duplicate IDs.
- Format all currency display values through one tested `NumberFormatter` (`0`, `999`, `1K`, `1.5K`, `1M`, `1B`, `1T`, `1Qa` or scientific after threshold). **Never** mutate underlying numeric values for presentation.
- Log errors with structured context (service, userId, productId, worldId, code). Avoid revealing raw sensitive internals in player toasts.
- Disable Studio-only debug grants/test commands on production universe; implement `DevOverrides` only guarded by Studio check/private allowlist and documented audit.
- No production runtime reliance on marketplace models with arbitrary embedded scripts. Strip/check imported models and use license-safe originals.

### 17.3 Executable starter service contracts

```lua
-- Examples of PUBLIC interface shapes (not complete implementation)

-- TrainingService
TrainingService.GetZoneAtPosition(player: Player, position: Vector3): string?
TrainingService.GetEffectiveSkillPerTick(player: Player): number
TrainingService.GrantTrainingTick(player: Player, dt: number): (boolean, number)

-- StoneService
StoneService.CanPurchase(player: Player, stoneId: string): (boolean, string)
StoneService.Purchase(player: Player, stoneId: string): (boolean, string)
StoneService.Equip(player: Player, stoneId: string): (boolean, string)

-- XPService
XPService.GetXPToNext(level: number): number
XPService.ApplyXp(profile: any, amount: number): number -- levels gained
XPService.GetLevelCap(rebirths: number): number

-- ThrowService
ThrowService.CanThrow(player: Player, worldId: string): (boolean, string)
ThrowService.ResolveThrow(player: Player, worldId: string): (boolean, any)

-- RebirthService
RebirthService.CanRebirth(player: Player): (boolean, string)
RebirthService.Rebirth(player: Player, origin: string): (boolean, string)

-- RewardService
RewardService.Grant(profile: any, rewardSpec: any, context: any): (boolean, string)

-- PurchaseService
PurchaseService.PromptPass(player: Player, passKey: string): (boolean, string)
PurchaseService.PromptProduct(player: Player, productKey: string): (boolean, string)

-- PlayerDataService
PlayerDataService.WaitForLoaded(player: Player, timeoutSeconds: number): any?
PlayerDataService.Mutate(player: Player, reason: string, fn: (any) -> ()): (boolean, string)
PlayerDataService.RequestSave(player: Player, priority: number): ()
```

**Important:** An interface signature is not a guarantee that calls to `Mutate` are automatically durable. Stateful services must specify transaction/locking behavior and have integrated tests.

### 17.4 Minimal deterministic XP function (illustrative)

```lua
local XPFormula = {}

function XPFormula.RequiredForNextLevel(level: number): number
    assert(type(level) == "number" and level >= 1 and level == math.floor(level))
    return math.floor((100 + 2.087 * (level ^ 2)) / 10 + 0.5) * 10
end

function XPFormula.LevelCap(rebirths: number): number
    return 50 + 10 * rebirths
end

function XPFormula.Apply(profile, xpAward: number): number
    local prog = profile.progression
    local cap = XPFormula.LevelCap(prog.rebirths)
    if prog.level >= cap then
        prog.levelXp = 0
        return 0
    end
    prog.levelXp += xpAward
    local gained = 0
    while prog.level < cap do
        local required = XPFormula.RequiredForNextLevel(prog.level)
        if prog.levelXp < required then break end
        prog.levelXp -= required
        prog.level += 1
        gained += 1
        if gained > 500 then
            -- Production implementation: use cumulative thresholds/binary search
            -- instead of this arbitrary per-tick loop cap for enormous grants.
            break
        end
    end
    if prog.level >= cap then prog.levelXp = 0 end
    return gained
end

return XPFormula
```

**The example has an explicit scalability caveat.** Production code must replace the 500-level bailout with an exact cumulative-threshold method; never leave partially processed XP in a way that lets one transaction unpredictably continue later. Verify `level` cap never exceeds the maximum safe cap in EconomyConfig.

### 17.5 Exact threshold skip algorithm to implement in production

For a target experience level `L`, define cumulative XP from Level 1 to Level L as `C(L) = Σ_{k=1}^{L-1} XPToNextLevel(k)`. Maintain `levelXp` plus `C(currentLevel)`, clamp target to `C(levelCap)`, then binary search integer `L` within `[currentLevel,levelCap]` such that `C(L) <= totalXp < C(L+1)`. The sum can be computed using a cached prefix array for practical caps (<=10,000) or incrementally generated values; ensure no huge loops during a single purchase. The result yields `level=L`, `levelXp=totalXp-C(L)`, or `levelXp=0` if cap reached. This handles 10K, 100K, 1M, and large purchasable awards correctly. Test exact boundary values, not just approximations.

### 17.6 Named workspace hierarchy example

```text
Workspace
  Worlds
    World1
      Geometry (Folder)
      SpawnPoints (Folder)
      TrainingZones (Folder) -> TrainingPoolBasic, TrainingPool4x, ...
      StoneStands (Folder) -> Stone_starter, Stone_shell, ...
      ThrowZones (Folder) -> MainThrowStation, CanalDecorations
      Portals (Folder) -> PortalToWorld2
      RewardStations (Folder) -> WelcomeChest, HarborEgg
      Leaderboards (Folder) -> TopWins, TopLevel, TopTime, TopRobux
    World2
      ...same collection-based conventions...
ReplicatedStorage
  Shared (Folder containing ModuleScripts)
  Remotes
  Assets (icon placeholders if needed)
ServerScriptService
  Server (server ModuleScripts + Main.server)
StarterPlayer
  StarterPlayerScripts
    Main.client (LocalScript)
StarterGui
  PlusOneGui (if authored as static Gui; otherwise build via Client Main)
SoundService
  Music (Folder)
```

---

## 18. ART, ASSETS, AUDIO, AND EFFECT PRODUCTION

### 18.1 Icon inventory to create or stub

All icons are original 1:1 cartoon game assets with transparent background unless a background is explicitly part of the button/card:

- Rebirth spiral arrows, gold trophy, Skill bolt, star/calendar, settings gear, update scroll, shopping basket, pet paw, trails/sword-like slash, backpack, gift box, friend-plus.
- Ten Stone silhouettes (pebble, shell, spiral shell, starfish, wood, sail/gem, ring, medal, dark disk, coral) as recognizable 3D prop thumbnails.
- Pool tier icons and seven zone banners in corresponding colors.
- Three Robux Skill product quantity icons + boost bottle x3 + double Skill/Win pass icons.
- Starter pack main pet, demon pack pet, four Harbor Egg pets, Fortune Neko, shooting star trail, chest, treasure/egg ticket, World 2 portal.
- Daily reward day-card gradients, badge highlights, inventory slot outlines, notification dot.

Placeholders may use simple gradient shapes and clear symbols, but every action must have a visible icon or title; exact original screenshot images **must never be cut into icon assets**. Confirm Roblox image upload rules if adding external textures. Include an `ASSET_MANIFEST.md` mapping key → file → upload asset ID or TODO.

### 18.2 VFX specification

- Training tick: neon lightning outline floats +skill over pad/character ~0.75s with vertical easing and fade. Combine too-fast events; never instantiate hundreds of world BillboardGuis per second indefinitely.
- Level up: `LEVEL UP!`, short chime, brief golden pulse behind bar, maybe 1–5 star particles. At +N levels show `+N LEVELS`.
- Stone purchase: ring pulse at pedestal, owned state flips, upgrade swoosh, discreet `+3 BASE SKILL` toast.
- Rebirth: swirl pink+cyan arrow effect, screen tint 0.4s, confetti minimal, reposition to spawn; obey Reduce Motion.
- Throw: launch swoosh, projectile trail, milestone sounds at interval, splash and `+WINS` trophy pulse. Camera shake has user setting and max amplitude; restore camera on death/interrupt.
- Portal: quick swirling aqua texture, frame glow and fade transition, server travel result controls final screen.
- Daily gift: card fill and checkmark, chest opening, animation optional skip.

### 18.3 Audio

Use separate SoundGroups or volume routing for `SFX`, `Music`, `UI`; Settings slider changes actual sound volume in client. Proposed cues: click, hover (subtle), error, stone purchase, training pickup every few ticks (not each tick if annoying), level-up, launch, splash, rebirth, portal, daily claim. Avoid unlicensed media; no blank asset IDs being played. Mobile default can start with music lower than SFX; respect user preferences and reduced sensory stimulation.

### 18.4 Performance budget

Targets are guidance to be verified with Roblox MicroProfiler/Stats on real devices:

- 30 FPS minimum on reasonable low-end mobile testing, 60 FPS on a typical desktop.
- No repeated creation/destruction of full UI tree on Skill tick; update labels in place.
- On-screen animated VFX cap per player; pool/stone prop idle rotation local client at low frequency or TweenService; no expensive server Heartbeat animations.
- Use simple collision geometry and fewer triangle-heavy meshes; limit 3D audio instances; anchor map parts.
- World 1 should not contain tens of thousands of individual stud pieces—use tiling textures or merged modular parts.
- Global board fetch asynchronous every ~2 minutes; never DataStore fetch on rendering/UI event.
- Client should skip distant pet particles, nonessential ambient effects, and leaderboards when low graphics options enabled.
- All Instance and connection allocations have cleanup ownership. Avoid unbounded tables keyed by departing players.

---
## 19. IMPLEMENTATION WORK ORDERS — AGENT MUST EXECUTE IN THIS ORDER

Each phase must produce running code, not just a checklist. Update `IMPLEMENTATION_STATUS.md` with exact completed files and the test result. After each phase, start Studio server/client Play test (or log inability). If Studio unavailable, run available static Luau tests/linter/checker and mark gameplay integration tests blocked until Studio access—not passed.

### Phase 0 — Capability and reference audit

**Tasks:**

1. Confirm repository root, ability to write files, Roblox Studio availability, Rojo availability, Luau tooling, and permissions to publish/test.
2. Read all 16 reference images from package and make a short internal inventory of UI / stations / worlds; do not ignore later settings or update log images.
3. Identify and record missing IDs: UniverseId, GroupId, pass IDs, developer product IDs, original icon assets, music, future places. Keep config fields `nil` if unknown.
4. Set original brand/theme defaults (`Pumpkin Harbor`, `Palm Beach`, `+1 Launch Skill Simulator`) and record the fact that the screenshots are not licensed design assets.
5. Create project tree, minimal README, and status tracking docs. Set up separate `DEV` storage namespace.

**Gate:** Source project opens/loads, and no unapproved asset IDs are in config.

### Phase 1 — Shared configuration and arithmetic

1. Create StoneCatalog, TrainingZoneCatalog, EconomyConfig, WorldConfig, ThemeConfig and relevant Types.
2. Implement NumberFormatter with suffix and rounding tests.
3. Implement exact XP progression and Level cap 50+10r; validate Level58 requirement ~7.12K and r3 cap80.
4. Implement Skill gain calculation with all multiplier categories, with configurable caps, including active pool = one zone only.
5. Implement Throw reward math with safe log and Win calculation; tune initial values using deterministic simulated profiles.
6. Add startup config asserts for positive costs, unique IDs, valid world targets, nonnegative thresholds, valid multiplier types, no missing references.

**Gate:** Math unit tests pass; no Roblox Instance dependencies in pure calculation modules.

### Phase 2 — Profile service and authoritative networking

1. Implement profile session manager, schema validator, migrations, load/unload, autosave, state snapshot, and transactions.
2. Create remotes and type/permission/rate-limit validators. Implement `GetInitialSnapshot` and `StateUpdate`.
3. On join, don't spawn unrestricted gameplay before profile loaded. On failure, display safe retry/rejoin state.
4. Create local Studio test profile mode isolated from production store; no unsafe debug grants in public servers.
5. Verify save/reload and profile migration. Write simulate/conflict tests for load failures and duplicate requests.

**Gate:** Rejoin shows exact saved Skill/Wins/owned Stone/rebirth; read failure never wipes existing data; unsafe client currency request rejected.

### Phase 3 — World geometry and travel

1. Programmatically build World1 floor/cliffs/concourse/trees, player spawn, safe boundaries.
2. Build seven pools and place signs/stations with tags, Attributes, trigger volumes, cost/lock labels.
3. Build 10 Stone stands in readable stepped plaza, put correct models/primitive substitutes on each stand.
4. Build 600-stud throw canal, start pad, safe throw visual anchor, milestone positions.
5. Add gift chest, one egg stand, World2 portal, leaderboards wall.
6. Build themed World2 and back portal, even if remote travel currently `samePlace`.
7. Test collisions, streaming, spawn orientation and path access using PC and touch camera.

**Gate:** Spawn → training → stones → throw → portal paths are physical and traversable, with no dead ends.

### Phase 4 — Complete the minimum earn/spend/rebirth loop

1. TrainingService detects server-measured active zones, grants Skill and XP at 1s cadence, recomputes multiplier and notifies HUD.
2. StoneService enforces Win spend, ownership, equip, proximity, and idempotent purchase.
3. ThrowService grants Wins once per valid throw, calculates distance on server, triggers client animation.
4. RebirthService verifies Level cap and resets only intended stats; updates persistent multiplier and cap.
5. WorldService gates World2 by Skill and teleports safely; returns to World1 after rebirth if necessary.
6. FriendBoostService counts friends in server and updates actual displayed bonus.

**Gate:** A fresh nonpaying test account can train, throw, get Wins, purchase +3 Stone, train faster, level up, eventually rebirth, and resume after reconnect with correct state. No UI shortcuts; use functioning 3D prompts if HUD not yet complete.

### Phase 5 — Persistent HUD and menus

1. Implement shared button/card/progress/number formatter components.
2. Build main HUD at desktop + mobile breakpoints, nav buttons, counters, Level bar, pool and Skill multipliers.
3. Wire server state replication; ensure labels update only on authoritative results.
4. Build Stone prompt UX, throw button/results, world gate dialog, Rebirth modal.
5. Create Settings and working toggles, modal keyboard/gamepad controls, safe-area support.
6. Create Shop, Daily, Pets, Inventory, Trails, Gifts and Update Log with functional navigation, loading/empty/error states.
7. Run interface sweep on resolutions: 1920×1080, 1366×768, 1280×720, 844×390 mobile landscape, 390×844 portrait, 768×1024 tablet portrait. Accept approximate screens; verify no clipped core CTA.

**Gate:** All mandatory nav buttons open their correct screen, panels close, counters are real, UI touch/control remains accessible.

### Phase 6 — Rewards, inventories, pets

1. Write RewardService and deterministic unit tests; use shared grant behavior.
2. Implement Daily reward 7-day schema and 24h cooldown; Day1 claim on brand-new profile.
3. Implement PlaytimeService and 2/5/10/15/30/60-minute claimables.
4. Implement Welcome Chest, optional server-verified community membership as additional reward.
5. Implement egg purchase/roll, four species, weighted rarity, persistent pet instance IDs, and equip cap.
6. Implement trail reward/equip and respawn restoration.
7. Implement boost count, activation, expiry, and client countdown.
8. Add tutorial first-time milestone flags and hints.

**Gate:** All rewards grant exactly once per eligibility, survive rejoin where applicable, display current state correctly.

### Phase 7 — Monetization and verified entitlements

1. Build ShopCatalog with `ProductId=0`, `GamePassId=0` placeholders explicitly disabled.
2. Write pass ownership check and caching; UI owns/pass locks reflect actual status.
3. Build one Product receipt processor with durable idempotency plus transaction race tests.
4. Configure product types and exact grant contents; test via Studio test harness + live published Roblox test where available. **Do not claim Studio purchase prompt simulations prove real receipt delivery.**
5. Implement Auto Win/Auto Rebirth after pass ownership and opt-in, with safe server timers and current-life warnings.
6. Fetch real price metadata on configured products (with error fallback) and display consistently.
7. Validate pack order (rebirth before Skill when both granted immediately), duplicate rewards, migration, and receipts during rejoin.

**Gate:** No grant occurs from client purchase prompt or forged remote; a duplicate valid receipt cannot double grant; unavailable products cannot falsely transact.

### Phase 8 — Leaderboards, effects, audio, performance

1. Build local leaderstats and physical global 4-board display.
2. Update ordered stores asynchronously and throttle reads/writes; empty data states look intentional.
3. Implement original/equivalent icon placeholders and VFX; include reduce-motion and hide-effects settings.
4. Music/SFX routing, sliders, click cues, appropriate ambient audio.
5. Profile server CPU/network and client render with 8–16 test players; optimize heavy props/UI. Remove debug spam and orphan connections.
6. Document architecture and config extensions. Generate minimal sample `new theme` instructions.

**Gate:** Zero continuous server errors under ordinary play, acceptable frame rate, leaderboard failures do not block gameplay.

### Phase 9 — Verification, balancing, handoff

1. Run all automated tests and human playtest checklist in §20–§21.
2. Balance simulated milestones. Log median time-to-first-Stone, time-to-first-rebirth, time-to-world2, and non-payer earnings.
3. Verify **one purchase price** is not a screenshot placeholder. Verify every optional disabled section says `Unavailable` or is hidden.
4. Document pass/product asset configuration steps and datastore Studio warnings.
5. Produce `.rbxlx`/`.rbxl`, source project, README, asset manifest, and TEST_RESULTS with links/paths.
6. Self-evaluate against Definition of Done; fix release blockers before declaring completion.

**Gate:** All P0 tests pass in actual environment or explicitly marked BLOCKED. P1 components present and tested for template-complete delivery. No false “all complete” claims.

---

## 20. TEST MATRIX — 80+ INDIVIDUAL ACCEPTANCE ASSERTIONS

Assign each test an ID and save outcome in `TEST_RESULTS.md`: `PASS`, `FAIL`, `BLOCKED`, `NOT RUN`, date/time, build commit/reference, tester, device, and evidence (screenshot/log video/console result). A source file's mere existence does **not** count as a test pass.

### 20.1 New player / progression (`CORE`)

- [ ] CORE-01 Fresh account spawns World 1 with Wins 0, Skill 0, Rebirth 0, Level 1.
- [ ] CORE-02 Starter Stone is owned, equipped, shows +1 flat gain.
- [ ] CORE-03 Entering 1x training pool starts Skill gain near one tick per second.
- [ ] CORE-04 Exiting pool stops gain after max tolerated boundary delay.
- [ ] CORE-05 Dead/respawning character does not continue earning from old position.
- [ ] CORE-06 Pool x4 with 0 rebirths is locked; x1 works.
- [ ] CORE-07 At 2 rebirths x4 pool becomes available; 4/6 thresholds work for x10/x20.
- [ ] CORE-08 Cannot stack two overlapping training pool multipliers.
- [ ] CORE-09 Effective Skill matches exact documented multiplicative formula.
- [ ] CORE-10 Level XP increases with Skill award and Level bar represents real threshold.
- [ ] CORE-11 XP crossing a level threshold advances Level exactly once.
- [ ] CORE-12 XP exceeding several thresholds advances correct number of levels.
- [ ] CORE-13 Level never exceeds current rebirth-specific cap.
- [ ] CORE-14 At Level 58 `XPToNext` renders ~7.12K under default formula.
- [ ] CORE-15 At Rebirth 3 cap is Level 80 and Skill rebirth multiplier x4.
- [ ] CORE-16 Level percentage indicator derives correctly from Level/Cap.
- [ ] CORE-17 Number Formatter displays 999, 1K, 1.5K, 1M, 1B, 1T correctly.
- [ ] CORE-18 Very large Skill/XP values do not hang/crash or produce NaN.

### 20.2 Stones / Wins / throws (`ACTION`)

- [ ] ACTION-01 Throw pad works with keyboard prompt E.
- [ ] ACTION-02 Same action available on touch via touch prompt.
- [ ] ACTION-03 Throw animation and distance/result popup appear after authoritative grant.
- [ ] ACTION-04 Throw distance is larger/equal as Skill grows; no negative distance.
- [ ] ACTION-05 Throw grants >=1 Win from zero Skill, without hidden paywall.
- [ ] ACTION-06 Second throw during cooldown grants no Wins.
- [ ] ACTION-07 Forged client distance or Win amount ignored/rejected.
- [ ] ACTION-08 Throw attempted remotely from outside pad fails.
- [ ] ACTION-09 First +3 Stone costs exactly 2 Wins.
- [ ] ACTION-10 +5 Stone costs exactly 10, +12 40, +30 150.
- [ ] ACTION-11 High tiers +75/500, +200/1500, +500/4500, +1250/14000, +3500/40000 correct.
- [ ] ACTION-12 Insufficient Wins purchase fails without reducing Wins.
- [ ] ACTION-13 Successful Stone purchase deducts exactly its configured cost.
- [ ] ACTION-14 Purchased Stone auto-equips if better; Skill tick improves.
- [ ] ACTION-15 Duplicated Stone purchase packet deducts no second cost.
- [ ] ACTION-16 Previously owned Stone can be re-equipped free.
- [ ] ACTION-17 Stone owned state and Wins remain accurate after rejoin and rebirth.
- [ ] ACTION-18 World 2 gate refuses <100M current Skill and permits >=100M.
- [ ] ACTION-19 World 2 return portal always works; cannot portal to arbitrary CFrame.
- [ ] ACTION-20 Throw camera always restores on disconnect/death/skip.

### 20.3 Rebirth (`RB`)

- [ ] RB-01 Rebirth modal shows actual before/after multiplier and exact reset list.
- [ ] RB-02 Rebirth cannot occur below Level cap.
- [ ] RB-03 Rebirth at cap increments count by exactly 1.
- [ ] RB-04 Rebirth resets Skill=0, Level=1, XP=0.
- [ ] RB-05 Rebirth preserves Wins, Stones, Pets, Trails and paid entitlements.
- [ ] RB-06 New Level cap increases by 10; multiplier increases by +1x.
- [ ] RB-07 Two simultaneous rebirth requests do not increment twice.
- [ ] RB-08 Rebirth moves player to a safe spawn.
- [ ] RB-09 Rebirth during World 2 removes current-Skill access and returns to World 1.
- [ ] RB-10 Auto-rebirth obeys pass, toggle, cap, and no double-rebirth behavior.
- [ ] RB-11 Skip Rebirth receipt, if configured, grants once and applies same reset order.

### 20.4 Rewards, pets, passes (`REWARD`)

- [ ] REWARD-01 Day 1 free to claim immediately for fresh profile.
- [ ] REWARD-02 Daily claim advances index and sets next claim timestamp +86400.
- [ ] REWARD-03 Second daily claim before next time rejected without extra reward.
- [ ] REWARD-04 Rejoin retains daily index/claim state.
- [ ] REWARD-05 Missed calendar day does not unexpectedly reset next reward.
- [ ] REWARD-06 Day 7 unique trail grants or documented duplicate compensation.
- [ ] REWARD-07 Playtime claim at 2min fails at 119s and succeeds at >=120s.
- [ ] REWARD-08 Playtime gift cannot be claimed twice same session.
- [ ] REWARD-09 Welcome Chest one-time claim works and persists.
- [ ] REWARD-10 Likes/Favorites are not falsely represented as API-verified.
- [ ] REWARD-11 Group membership reward, when enabled, uses server membership check.
- [ ] REWARD-12 Friend boost updates on real friend joining/leaving same server.
- [ ] REWARD-13 Egg costs 150 Wins and rolls one valid pet species, no client-selected rarity.
- [ ] REWARD-14 Pet's persistent instance ID survives rejoin and deletion handling.
- [ ] REWARD-15 Equip slot limit enforced by server; duplicates can't bypass.
- [ ] REWARD-16 Multipliers update correctly when Pet equipped/unequipped.
- [ ] REWARD-17 Boost timer expires at server UTC and does not stack multiplicatively with itself.
- [ ] REWARD-18 Owned cosmetic trail is restored on character respawn.
- [ ] REWARD-19 No Game Pass effect without ownership verification.
- [ ] REWARD-20 Pack cannot silently grant fake ownership of another marketplace pass.
- [ ] REWARD-21 Starter Pack permanently grants in-game 2x Skill and 2x Wins if purchased/received via verified receipt; effects survive rejoin.
- [ ] REWARD-22 Bundle 2x benefit and individually owned 2x Game Pass cannot multiply into unintended 4x of that same category.

### 20.5 Purchase and data security (`SEC`)

- [ ] SEC-01 Forged RequestBuyStone(amount=-1000000) cannot create Wins.
- [ ] SEC-02 Forged RequestThrow(distance=99999) cannot grant more Wins.
- [ ] SEC-03 Client-supplied fake multipliers never affect server Skill award.
- [ ] SEC-04 Repeated invalid remotes rate-limited with bounded memory use.
- [ ] SEC-05 Purchase prompt completion does not itself grant Developer Product.
- [ ] SEC-06 First valid receipt grants intended durable product once.
- [ ] SEC-07 Repeated same PurchaseId grants no additional item nor Robux spend.
- [ ] SEC-08 Receipt with unknown ProductId not acknowledged/granted as valid supported item.
- [ ] SEC-09 Product receipt arriving while profile unloaded is safely retried, not lost.
- [ ] SEC-10 Purchase during a pending autosave survives and isn't overwritten.
- [ ] SEC-11 Invalid GamePass/Product ID leaves UI disabled, no fake R$ price.
- [ ] SEC-12 Ownership check failure shows retry/error; no unverified paid benefit.
- [ ] SEC-13 Game Pass prompt server confirmation updates access correctly.
- [ ] SEC-14 Session locks prevent concurrent writable state for one UserId.
- [ ] SEC-15 Load failure does not produce starter profile that overwrites real data.
- [ ] SEC-16 Save failure surfaces suitable status and retries without flooding.
- [ ] SEC-17 Production experience does not allow Studio-only debug grants.
- [ ] SEC-18 Large payload/string/table packets rejected promptly.
- [ ] SEC-19 Future-dated daily timestamp and malformed old profile cannot generate infinite claims.
- [ ] SEC-20 PlayerLeaving/BindToClose flushes data within practical Roblox limits.

### 20.6 UI, world, device, observability (`UX`)

- [ ] UX-01 Shop, Rebirth, Pets, Trails, Inventory, Gifts all open correct screens.
- [ ] UX-02 Settings and Update Log actions open and close reliably.
- [ ] UX-03 Sound slider changes real sound volume; Music slider independently changes music.
- [ ] UX-04 Camera Shake OFF prevents throw/rebirth camera shake.
- [ ] UX-05 Effects OFF reduces nonessential particles; gameplay still understandable.
- [ ] UX-06 Hide HUD OFF/ON shows expected HUD and always provides a restore control.
- [ ] UX-07 No essential button hidden by CoreGui/safe area on desktop.
- [ ] UX-08 No essential button clipped/untappable at 390×844 portrait.
- [ ] UX-09 No essential button clipped/untappable at 844×390 landscape.
- [ ] UX-10 Gamepad can navigate modal actions and close them.
- [ ] UX-11 Lock state is legible without distinguishing red vs green alone.
- [ ] UX-12 Pedestal BillboardGuis don't overlap catastrophically at 15-stud distance.
- [ ] UX-13 Buildings/paths/portals are physically traversable without snagging.
- [ ] UX-14 Global board shows fetched values or explicit empty/loading state, never fabricated rankings.
- [ ] UX-15 Global board failures don't block currency/skill updates.
- [ ] UX-16 8-player Studio test has no persistent runtime errors.
- [ ] UX-17 16-player simulation maintains playable controls/Skill timing.
- [ ] UX-18 Pet follows and VFX clean up after player departure; memory doesn't grow monotonically with joins.
- [ ] UX-19 All active features in Update Log genuinely exist; no fake patch notes.
- [ ] UX-20 Template is re-themeable by config without rewriting reward/profile systems.

---

## 21. BALANCING REQUIREMENTS AND SIMULATION HARNESS

The screenshots show explosive-looking multipliers, yet an enjoyable game needs quick early gains and long-term goals. Implement a **deterministic offline progression simulator** that consumes EconomyConfig/StoneCatalog/PoolCatalog and models multiple player strategies. Store results in `BALANCE_REPORT.md`; do not claim the screenshot's original economy is known.

### 21.1 Test strategies

- **Casual free player:** 60% train / 25% throw / 15% buy and navigation, always buys best affordable Stone, rebirths at cap.
- **Optimized free player:** 75% train / 15% throw / 10% shop, chooses best affordable pool/Stone, immediate rebirth unless World gate target near.
- **Casual purchaser:** Owns doubleSkill/doubleWins but not exclusive pool; buys Starter Pack once.
- **Whale stress profile:** all passes, rare equipped pets, 50 rebirths, premium 50x pool, large stats near cap. Used for stability, not to set economy in a pay-to-win loop.
- **Inactive/misguided player:** spends first minute exploring, follows basic prompts, ignores gift/chest, still makes progress.

### 21.2 Metrics / target bands (recommended tuning targets)

| Metric | Target on fresh free profile | Notes |
|---|---|---|
| First Skill tick | <=20s after spawn | Clear directions |
| First Throw action | <=45s | No prerequisites |
| First two Wins | <=90s | Purchase +3 Stone |
| First Stone purchase | 1–3min | Visual `+3` milestone |
| First visible Level-up | <=2min | XP curve may need starter tutorial bonus if otherwise too slow |
| +12 Stone purchase | ~4–8min | Rough, tune via simulation |
| First Rebirth | ~10–20min | Not a hard promise, adjust progression |
| Accessible x4 Rebirth pad | After second rebirth | Conveys permanent progression |
| World2 at 100M Skill | Long-term goal / multiple sessions | Must remain reachable eventually without paying |
| Daily login reward | Available immediately | 24h cooldown after claim |

If results wildly miss targets, annotate revised parameters in `BALANCE_REPORT.md` and update central config. Do not stealth-drop level cap or inflate base Skill rewards only for paid users. Respect an accessible free-to-play path.

### 21.3 Simulation accuracy

Simulated training rate must be the same function as server's gameplay function (import pure function or share ModuleScript). Simulated Wins require throw cooldown and travel/action time, not instantaneous infinite throws. Include Stone prices, rebirth reset of Level/Skill (not Wins/Stones), pool access thresholds, and boost expiration if modeled. Run at least 100 deterministic seeds for random pet choices where relevant and report median, P10/P90 milestones. Use nominal latency/UI travel overhead to avoid unrealistically optimistic targets.

### 21.4 Diagnostics / KPIs (privacy conscious)

Emit low-volume internal events: `session_start`, `tutorial_step_completed`, `stone_bought`, `throw_completed`, `level_milestone`, `rebirth_completed`, `world_entered`, `daily_claimed`, `playtime_reward_claimed`, `shop_opened`, `purchase_prompted`, `receipt_fulfilled`, `session_end`. Event payload should contain anonymous userId identifier only if necessary and permitted, world/Stone IDs and small numeric aggregates, no chat contents/sensitive data. Metrics to review after launch: D1/D7 retention, median session duration, first-action completion, stone funnel, rebirth frequency, world unlock distribution, crash/save failures, developer product errors, mobile UI abandonment. Disable analytics cleanly if infrastructure unavailable; do not block playing.

---

## 22. POLISH AND SAFETY EDGE CASES — MUST NOT BE IGNORED

**Profile/session:** A user leaving while a confirmation menu is open, rejoining on a different server, changing avatar between pad ticks, server shutdown under write throttle, and store key renamed after update must not reset inventory. Account data migration tests use representative saved old profiles. Never let a client UI timer replace server time.

**Currency:** Spend equal-to-cost (`wins == cost`) succeeds; just below cost fails; buy two separate items quickly cannot overspend; earning Wins while purchasing Stone yields one serializable result. Lifetime Wins increases only when actual Wins granted, never when refunded/granted by mistake. Currency displays gracefully format 0, negatives (should be impossible), 999.99 if developer accidentally produces decimal, and 1e15; invalid values repaired server side safely.

**Level:** XP to next never 0, cap correct at r=0/3/50, exact threshold at `N-1`, `N`, and `N+1` XP, large 1M Skill purchase from Level 1, leveling while inside pool with temporary buffs expiring mid-tick, cap arrival triggering auto-rebirth simultaneously with normal rebirth click.

**Physics:** A user walking on edge between pool triggers, dying inside an active trigger, being teleported directly from pool to world portal, arbitrary client CFrame teleport attempts, two players entering pad simultaneously, broad touch part triggering as decorative item moves, latency when visual throw projectile lands before results, camera restore from throw if avatar resets.

**Worlds:** User with exactly required Skill can enter; with just below cannot. World destination may be streamed out; robust teleport includes safe spawn. Player cannot bypass gate by touching world boundary / teleport exploit to obtain World 2 multipliers—server validates currentWorld AND actual registered zone location. A user rebirthing in World 2 never gets stuck in a gated world while Skill=0. New world with no WorldSpawn configured is disabled at boot with clear warning.

**Social:** Server friend count 0..5 cap, friend leaving resets effect, group check caches membership until rejoin, unavailable like/favorite APIs never lied about, group membership failure should not hide free Welcome Gift.

**Shop:** False purchase prompt finished event ignored, pass ownership changes mid-session refreshed, price lookup fails gracefully, SKU retired/disabled after update, duplicate product receipts, pack reward at cap, user buying one-time product again through external marketplace, unknown receipt ProductId, premium launch zone accessed without verified Game Pass by collision hopping (server rejects). A Robux purchase never grants through Win-spend endpoint.

**Rewards:** Two simultaneous daily claims, claiming at one second before/after 24h, server UTC date turnover, boosts after server restart, Day 7 already-owned trail compensation, playtime gift claiming at exactly threshold, click from remote outside chest, zero inventory space, luck weights sum after modifiers, egg hatch in rapid succession.

**User experience:** Player with long username on leaderboards, localized strings wider than English, 3D fonts under sunset lighting, very tall avatar reaching occluding signs, player with lower-end device using Reduced Motion and Low Effects, no controller cursor, network packet delayed/out of order, all overlays closed while tutorial arrow persists. All must degrade gracefully.

---

## 23. DEFINITION OF DONE — RELEASE GATES

An AI building this game must **not** conclude with “template complete” until it can demonstrate:

**Core function**

- Fresh user enters a real 3D map with a basic pool, a Stone stage, a Throw lane, and a portal.
- Skill ticks on valid pads, Levels advance, effective multiplier and buff labels are correct, Throw earns server-computed Wins, Wins buy Stone tiers, and Rebirth obeys cap and reset semantics.
- Two worlds exist and current-Skill gate works. World1 free path remains enjoyable without Robux.

**Data/robustness**

- Skill, Wins, equipped/owned Stone, rebirth count, current Level and XP, rewards, pets, and settings persist appropriately.
- No cheat client can set Skill/Wins, bypass pool World or pass unlocks, or replay daily/rebirth/stone transaction for profit.
- Real Developer Product receipts have idempotent durable handling, or all IDs/products remain intentionally disabled with clear documentation and no false test claims.

**UI/quality**

- All listed HUD/menu components work, including Settings, Daily, Shop, Rebirth, Update Log, Gifts, Inventory, Pets, Trails; their visible actions have real effects or a clearly labeled unavailable state.
- Visual feel matches the *style* of the references (bright studded map, giant outlined counters, fun colored pools), without copying reference assets.
- Screens usable on desktop, phone and gamepad; art/effects optimized reasonably.
- Real/empty leaderboard behavior, readable world labels, working friend boost, no forced purchase popup.

**Handoff**

- Runnable `.rbxl` / `.rbxlx` and/or working Rojo project, documented Studio assembly/launch, complete source, `README`, central configs, test report, balance report, original asset manifest, known issues.
- Actual PASS/FAIL/BLOCKED test outcomes with environment constraints; all P0 test gates pass where runtime available.
- Developer can change display stat, Stone progression, costs, pool gates/multipliers, Worlds and themes from catalog/config.

**Failure conditions:** A static copied UI without game logic; economy calculated on LocalScripts; fake purchased gamepasses; missing/incorrect receipt handling; saving only on leave; assets copied from references; World 2 sign with no world behind it; buttons that open empty pages; made-up test evidence; Robux prices hard-coded from source screenshot; inaccessible phone UI.

---

## 24. REQUIRED AGENT FINAL REPORT FORMAT

The implementing AI should produce a clear report to the owner using this exact outline:

```text
1. BUILD STATUS: COMPLETE / PARTIAL / BLOCKED
2. DELIVERABLES:
   - Place: <actual verified path or Not created>
   - Source project: <actual verified path>
   - Test results: <actual verified path>
   - Other artifacts: <list>
3. WHAT WORKS:
   - Core Skill/Level/Wins/Stone/Rebirth/World features (individual statuses)
   - Daily, Playtime, Shop, Passes, Pets, Trails, Settings, Boards
4. REAL TEST EVIDENCE:
   - Device/Studio/Roblox Client and test cases passed
   - Data persistence test and receipt-idempotency test results
5. WHAT IS STILL NEEDED FROM OWNER:
   - Group ID, Product IDs, Pass IDs, branding/art, publishing permissions, etc.
6. OPEN ISSUES AND RISKS:
   - Exact repro, severity, expected fix
7. HOW TO OPEN / RUN / MODIFY:
   - Studio / Rojo / required setup
8. NEXT MOST VALUABLE TASKS:
   - Ranked, scoped follow-up actions
```

If publishing/MarketplaceService IDs unavailable, deliver disabled monetization that has no fake purchase behavior and mark activation instructions clearly. If Studio unavailable, do not list `PASS` for playtests that could not happen.

---

## 25. OFFICIAL ROBLOX API REFERENCES TO VERIFY DURING BUILD

**Always check documentation again when implementing**—Roblox APIs and policy can change. These are official starting references, not source code for this game:

1. Creator Hub — Data Stores: https://create.roblox.com/docs/cloud-services/data-stores
2. Data Store Best Practices: https://create.roblox.com/docs/cloud-services/data-stores/best-practices
3. Server/client trust boundary: https://create.roblox.com/docs/scripting/security/client-server-boundary
4. Developer Products and receipt requirements: https://create.roblox.com/docs/production/monetization/developer-products
5. MarketplaceService reference: https://create.roblox.com/docs/reference/engine/classes/MarketplaceService
6. Player reference (`IsInGroupAsync`, `IsFriendsWithAsync`): https://create.roblox.com/docs/reference/engine/classes/Player
7. TeleportService reference: https://create.roblox.com/docs/reference/engine/classes/TeleportService
8. MemoryStoreService reference: https://create.roblox.com/docs/reference/engine/classes/MemoryStoreService
9. Roblox discovery/promotion guidance: https://create.roblox.com/docs/discovery
10. Roblox safety guidance: https://create.roblox.com/docs/safety

**Known platform notes:** (A) Studio access to live datastores can be dangerous; test only in dev namespace/universe. (B) Roblox recommends validating all client-triggered progression requests server-side, including ProximityPrompt activations. (C) Developer Product fulfillment must not rely on prompt completion; use verified receipt handling. (D) `Player:IsInGroupAsync()` exists but membership responses may be cached. (E) Multi-place teleports may require a published Roblox client test, not only Studio. (F) Individual Like/Favorite verification and policy should not be assumed; build the Welcome Gift without false verification. (G) Developer product prices may be personalized; only Roblox authoritative metadata should define visible actual price.

---

## APPENDIX A — OWNER-EDITABLE STARTER CONFIG MATRIX

| Owner decision | Default | Edit location | Requires publishing/setup? |
|---|---|---|---|
| Game name | +1 Launch Skill Simulator | ThemeConfig | No |
| Main stat | Skill | ThemeConfig | No |
| Spendable soft currency | Wins | ThemeConfig | No |
| First rebirth cap | 50 Levels | EconomyConfig | No |
| Cap increase/rebirth | +10 | EconomyConfig | No |
| Rebirth multiplier step | +1x | EconomyConfig | No |
| Stone count | 10 | StoneCatalog | No |
| Stone costs | 0/2/10/40/150/500/1500/4500/14000/40000 | StoneCatalog | No |
| Free pool access | 0/2/4/6 rebirths | TrainingZoneCatalog | No |
| Premium multipliers | 3x/15x/50x | TrainingZoneCatalog | Yes, Game Pass IDs |
| World2 gate | 100M Skill | WorldConfig | No |
| World2 multiplier | 2x Skill/3x Wins | WorldConfig | No |
| Daily reset policy | 24h after claim | RewardConfig | No |
| Pet equip slots | 3 | PetCatalog | No |
| Friend boost | +10% per same-server friend, cap50% | EconomyConfig | No |
| Welcome Gift | +10K Skill, once | RewardConfig | No |
| Starter Pack core effects | Permanent in-game 2x Skill + 2x Wins (non-stacking with equivalent pass) | ShopCatalog / EntitlementService | Yes, Developer Product ID |
| Group ID | None (optional feature off) | Shop/CommunityConfig | Yes |
| Pass IDs | All disabled | ShopCatalog | Yes |
| Developer Product IDs | All disabled | ShopCatalog | Yes |
| Sound and 2D assets | Original placeholders | ASSET_MANIFEST | Upload may be needed |
| Analytics | Disabled unless configured | AnalyticsConfig | Optional |
| Ordered boards | Enabled if DataStores operational | LeaderboardConfig | Publish/testing required |

---

## APPENDIX B — REFERENCE SCREENSHOT → FEATURE TRACEABILITY

Use this at final review so no reference is ignored:

| Screenshot | Required subsystem | Acceptance evidence |
|---|---|---|
| 01 / 06 | Stone stage | Ten 3D models, labels, costs, buy/equip, persistence |
| 02 | Training pools | Seven lanes, appropriate gates/multipliers |
| 03 / 04 | Main HUD | Counters, nav, Skill/XP/Level, quick-buy cards, multiplier |
| 05 | Throw action | Water canal, pad, server-awarded Wins, animated distance |
| 07 / 08 | Free/Community gift | Real Welcome Chest and one-time gift modal; no fake social verification |
| 09 | Leaderboards | Boards populated from datastore or empty/loading, no fake accounts |
| 10 | Rebirth | Before/after, reset notice, cap bar, working transaction |
| 11 | World travel | World2 gate and functional Palm Beach destination |
| 12 / 13 | Shop | Bundles, gamepasses, AFK systems, price/owned states |
| 14 | Daily rewards | Seven-day UI, item grants, server countdown, persistence |
| 15 | Settings | Functional audio/sliders/effects/HUD settings |
| 16 | Update log | Dated data-driven actual patch notes only |

---

## APPENDIX C — NON-GOALS, EXPLICIT DEFAULTS, AND FUTURE EXTENSIONS

**Non-goals:** Competitive PvP, trading real-money goods, gambling with Robux-based mystery prizes, unsupported likes/favorites verification, scripting arbitrary admin abuse events, server cross-place teleports by default, offline 24/7 AFK farming, dynamic cash-out, copy-pasted proprietary art, unnecessary pets with combat AI, unrealistic world auto-generation that ignores geometry.

**Explicit intentional differences from the references:** World name/theme is original; we use a clear reliable World2 destination, not simply a portal sign. Stone `AVAILABLE` vs `OWNED` differs from screenshot's ambiguous `UNLOCKED`; logic is intentionally clearer. Community chest is a genuine one-time Welcome Gift without unverifiable social gating. Premium prices are not copied from screenshots. Original characters/pets/icons/models must be built or licensed. First gameplay release includes basic Pet/Egg and simple World2, with future content defined by config.

**Future expansion ideas, outside minimum template:** Seasonal Worlds 3–6 with stone ladder per world, timed event pass, achievement badges, quests, pet fusion, pet index/collection reward, platform entitlement parity, rejoin streak cosmetics, prestige milestones, cloud analytics experiments, server time boosters, global events, optional race/jump adapters. Future systems must reuse existing RewardService, PlayerDataService, WorldService, and shared catalog patterns.

---

## FINAL INSTRUCTION TO THE BUILD AGENT

**Start implementing now.** Begin with configuration/math, then secure player data and a small functional world slice. Do not produce only another design essay. Revisit screenshot references while implementing each system. Once the full test matrix is checked, provide the actual place/project artifacts, tests, setup instructions, and honest status. Prioritize a reliable, re-themable, playable base over flashy but nonfunctional visuals.

**END OF SPECIFICATION.**
